

from tkinter import NO
from geopy.geocoders import Nominatim

import telebot
import Globals
import Button
import Function_call
import Near_me
import Database
import Helper
import API
from PIL import Image
from io import BytesIO
import Keyboard_button
from geopy.exc import ConfigurationError

try:
    # Provide a custom user agent during geocoder initialization
    geolocator = Nominatim(user_agent="my-application", timeout=10)
    location = geolocator.reverse("7.663053, 36.849781", addressdetails=True)
except ConfigurationError as e:
    print(f"Error: {e}")







bot = telebot.TeleBot(API.API_KEY)


def handle_location(message):
    
    chat_id = message.chat.id
    # for sign up registration
    if  'manage' in Globals.user[chat_id]and 'account_registration' in Globals.user[chat_id]['manage']:
        current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        if current_question is not None:
            print(message.location)
            Globals.user[chat_id]['manage']['account_registration'][current_question] = message.location
            
            location(chat_id,Globals.user[chat_id]['manage']['account_registration'][3].latitude,Globals.user[chat_id]['manage']['account_registration'][3].longitude)
            Function_call.ask_question(chat_id, current_question + 1)

        else:
            bot.send_message(chat_id, " /start.")
    # for editing user information
    elif 'manage' in Globals.user[chat_id]and 'edit user' in Globals.user[chat_id]['account_sign_in'] and 'edit user' in  Globals.user[chat_id]['manage']['account_sign_in']:
        current_question =  Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)
        if current_question is not None and current_question == 3 :
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.location
             
            location(chat_id, Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3].latitude, Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3].longitude)
            Function_call.ask_question(chat_id, current_question + 1)

        else:
            text_message = "Please provide the correct file type which is Location " if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ ትክክለኛውን የፋይል አይነት ያቅርቡ ይህም ቦታ" if Globals.user[chat_id]['language'] == 'amharic' else "Please provide the correct file type which is Location " )
            bot.send_message(chat_id, text_message)
            Function_call.ask_question(chat_id, current_question + 1)

    elif 'search room' in Globals.user[chat_id]:
        # Globals.user_location[chat_id] = message.location
        city_name = location(chat_id, message.location.latitude, message.location.longitude)

        if city_name == None:
            bot.send_message(chat_id,"sorry cant found the name of your city")
            return

        text_message = " All hotels or filter based on room price " if Globals.user[chat_id]['language'] == 'english' else ( "ሁሉም ሆቴሎች ወይም ማጣሪያ በክፍል ዋጋ ላይ የተመሰረተ" if Globals.user[chat_id]['language'] == 'amharic' else " All hotels or filter based on room price " )
        bot.send_message(message.chat.id, text_message, reply_markup=Button.search_room(chat_id,1))
        Globals.user[chat_id]['search room']['search by']['search property']['city_name'] = city_name
        Globals.user[chat_id]['search room']['search by']['search property']['content'] = message

        Globals.user[chat_id]['button_semaphore'] = 0
        
        
    else:
        text_message = "Please answer with correct answer format." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛው የመልስ ቅርጸት ይመልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
        bot.send_message(chat_id, text_message)



def get_location_info(latitude, longitude):
    geolocator = Nominatim(user_agent="your_app_name")  # Replace "your_app_name" with your app's name
    location = geolocator.reverse((latitude, longitude), exactly_one=True)
    return location


def location(chat_id,latitude,longitude):
  
    location_info = get_location_info(latitude, longitude)
    if location_info:
        address = location_info.address
        print("Address:", address)
        country = location_info.raw.get("address", {}).get("country")
        city = location_info.raw.get("address", {}).get("city")
        #print("city:", city)
        

        
        try:
            city_name = [part.strip() for part in city.split('/')]
            print("City:", city_name[1])

            userId_query = "UPDATE UserId set City_Location = '"+str(city_name[1])+"' where User_TelegramId = '"+str(chat_id)+"'"
            Database.cursor.execute(userId_query)
            Database.conn.commit()

            if 'manage' in Globals.user[chat_id] and  'account_sign_in' in Globals.user[chat_id]['manage'] and'edit user' in Globals.user[chat_id]['manage']['manage']:
                Globals.edited_user_info[chat_id][2] = city_name[1]
            elif 'manage' in Globals.user[chat_id] and 'account_registration' in Globals.user[chat_id]['manage']:
                Globals.user[chat_id]['manage']['account_registration'][2] = city_name[1]
            elif 'search room' in Globals.user[chat_id]:
                return city_name[1]
        except:
            print("something not wright")
       
        
    else:
        print("Location information not found.")



def get_hotels(chat_id,city_name,latitude,longitude,message_id,message=None):
    if message_id != None:
        bot.edit_message_reply_markup(chat_id=chat_id,message_id=message_id,  reply_markup=None)
    
    upper_lat =  latitude + (latitude *0.0006) 
    upper_lon = longitude + (longitude *0.0006)

    lower_lat =  latitude - (latitude *0.0006) # Paris, France
    lower_lon = longitude - (longitude *0.0006)
    # Near_me.haversine_distance(lat1, lon1, lat2, lon2)
    

    
    # min_price = None
    # max_price = None
    # if message != None:
    #     sent_message = message
    #     if sent_message.isdigit():
    #         min_price = '0'
    #         max_price = str(sent_message)

    #     elif '-' in  sent_message:
    #         result = str.split(message, "-")
    #         min_price = result[0].lstrip()
    #         min_price = min_price.rstrip()

    #         max_price = result[1].lstrip()
    #         max_price = max_price.rstrip()
    #         print('okay')
        
    #     else:
 
    #         Keyboard_button.back_to_search(chat_id)
        
    #         Globals.search_by[chat_id] = "price"
    #         #Globals.offset[chat_id] = 0

    #         text_message = "please enter the range of your price \n  in a format of minimum - maximum" if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ" if Globals.user[chat_id]['language'] == 'amharic' else "please enter the range of your price \n  in a format of minimum - maximum" )
    #         bot.send_message(chat_id,text_message)
    #         return

    #     if min_price.isdigit() and max_price.isdigit():
    #         print("okay")          

    #     else:
 
    #         text_message = " please the prices should numbers \n enter the range of your price \n  in a format of minimum - maximum" if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ" if Globals.user[chat_id]['language'] == 'amharic' else "please enter the range of your price \n  in a format of minimum - maximum" )
    #         bot.send_message(chat_id,text_message)
    #         return
   
    
    query = None
    if message != None:
        min_price,max_price = Helper.price_filter(chat_id,message)
    
        if min_price ==  -1 and max_price == -1:
            return
        query = "select DISTINCT Users_id,Hotel_name,City_location,GPS_location_latitude,GPS_location_longitude,Hotel_image,users.Hotel_priority,Phone_number,users.NEWIDS from users Inner Join Rooms on users.Users_id = Rooms.Hotel_id  where City_location = '"+str(city_name)+"' AND GPS_location_latitude between "+ str(lower_lat) +" and " + str(upper_lat) + " and GPS_location_longitude between " + str(lower_lon) + " and " + str(upper_lon) + " and Room_price >= "+ str(min_price) + " and  Room_price <= "+ str(max_price) + " order by users.Hotel_priority DESC, users.NEWIDS OFFSET " + str(Globals.user[chat_id]['search room']['offset']) +" ROWS FETCH NEXT 5 ROWS ONLY;"

    else:

        query = "select DISTINCT Users_id,Hotel_name,City_location,GPS_location_latitude,GPS_location_longitude,Hotel_image,Rooms.hotel_id,Phone_number,users.Hotel_priority, users.NEWIDS from users Inner Join Rooms on users.Users_id = Rooms.Hotel_id where City_location = '"+str(city_name)+"' AND GPS_location_latitude between "+ str(lower_lat) +" and " + str(upper_lat) + " and GPS_location_longitude between " + str(lower_lon) + " and " + str(upper_lon)+" and Room_price > 0 order by users.Hotel_priority DESC, users.NEWIDS DESC OFFSET " + str(Globals.user[chat_id]['search room']['offset']) +" ROWS FETCH NEXT 5 ROWS ONLY;"
    print(query)
    try:
        Database.cursor.execute(query)
        # Fetch the results
        rows = Database.cursor.fetchall()

        
        print(rows)

        if len(rows) == 0:
            bot.send_message(chat_id,"Sorry no near by hotel or motel rooms are available")
            return
        
        #if all resulted near by hotels dont posses a room
        No_Room = True
        for row in rows:
            hotel_id = row[0]
            room_id = None

            img_byte_array = None

            # with open(row[5], 'rb') as photo:
               
            #     image = Image.open(photo)
               
            #     # Resize the image to the desired dimensions
            #     width = 300
            #     height = 200
            #     image.thumbnail((width, height))

            #     # Convert the resized image to bytes
            #     img_byte_array = BytesIO()
            #     image.save(img_byte_array, format='JPEG')
            #     img_byte_array = img_byte_array.getvalue()
                
                    
                

            sub_query = None
            buttonImage = None
            message_text = "Located in " + row[2] +"  " + row[1] + " Hotel " + Near_me.haversine_distance(row[3], row[4], latitude, longitude) + " is apart from your location \n\n"
            if message != None:
                sub_query = "SELECT room_id, Room_type,Room_price FROM Rooms WHERE Hotel_id = "+str(row[0])  + " and Room_price >= "+ str(min_price) + " and  Room_price <= "+ str(max_price)
                # room_id = row[13]
                print(sub_query)
                room_identifier = [row[0],min_price,max_price]
                #room_identifier = str(hotel_id) + '-' +str(min_price)+"-"+str(max_price)
                callback_data = f"detail_image_R_{'-'.join(map(str, room_identifier))}"
                # buttonImage = telebot.types.InlineKeyboardButton(text="Room Image", callback_data=callback_data)
                Helper.return_info(chat_id,row[5],sub_query,row[1],callback_data,f"detail_location_{hotel_id}"," 📞 "+str(row[7]),message_text)
            else:
                sub_query = "SELECT room_id, Room_type,Room_price FROM Rooms WHERE Hotel_id = "+str(row[0])
                print(sub_query)
                # room_id = hotel_id
                # buttonImage = telebot.types.InlineKeyboardButton(text="Room Image", callback_data=f"detail_image_H_{room_id}")
                Helper.return_info(chat_id,row[5],sub_query,row[1],f"detail_image_H_{hotel_id}",f"detail_location_{hotel_id}"," 📞 "+str(row[7]),message_text)


        #     Database.cursor.execute(sub_query)
        #     # Fetch the results
        #     sub_rows = Database.cursor.fetchall()
        #     print(sub_rows)
            
        #    # if no room information is available skip it
        #     if len(sub_rows) == 0:
        #         continue
        #     else:
        #         No_Room = False
        #         sub_message = ""
        #         for sub_row in sub_rows:
                
        #             sub_message = str(sub_message) + " 🏨 room type " + str(sub_row[1]) + " 💰 room price "+ str(format(sub_row[2],',') + " Birr") + "\n"
                
        #         message_text = "Located in " + row[2] +"  " + row[1] + " Hotel " + Near_me.haversine_distance(row[3], row[4], latitude, longitude) + " is apart from your location \n\n" + sub_message
            

        #         # Create an inline keyboard
        #         Detail = telebot.types.InlineKeyboardMarkup()
            
        #         buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=f"detail_location_{hotel_id}")
        #             # Add the button to the keyboard
        #         Detail.add(buttonImage,buttonLocation)
        #             # Send a message with the inline keyboard
        #         bot.send_photo(chat_id, photo=Helper.show_image(row[5]),caption=message_text,reply_markup=Detail)
        #         #bot.send_message(chat_id,message, reply_markup=Detail)

        # if No_Room:
        #     bot.send_message(chat_id,"sorry no near by hotel room")

        
        
        if(len(rows) == 5):
            text_message = "\n See more rooms" if Globals.user[chat_id]['language'] == 'english' else ( "\n ተጨማሪ ክፍሎችን ይመልከቱ" if Globals.user[chat_id]['language'] == 'amharic' else "\n See more rooms" )
            sent_message = bot.send_message(chat_id, text_message, reply_markup=Button.load(chat_id))
            Globals.user[chat_id]['message_id'] = sent_message.message_id

    except Exception as e:
        print(f"Retrieve failed: {str(e)}")

