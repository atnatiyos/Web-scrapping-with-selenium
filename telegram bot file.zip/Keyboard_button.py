
import telebot
from telebot import types
import Globals
import Display
import Helper
import Button
import Function_call
import API
import Display





bot = telebot.TeleBot(API.API_KEY)

def back_to_search(chat_id):
    

    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    if 'search_based' in Globals.user[chat_id]['search room']['search by']['search property'] and Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "all":
        
        menu_markup.row(Button.filter_by,Button.Back_to_search)
    elif 'search_based' in Globals.user[chat_id]['search room']['search by']['search property'] and Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "price":
        #Button.all
        menu_markup.row(Button.all,Button.Back_to_search)
    else:
        print("in side back to search")
        menu_markup.row(Button.Back_to_search)

    message_text = "\n"

    if 'name_or_near' in Globals.user[chat_id]['search room']['search by'] and Globals.user[chat_id]['search room']['search by']['name_or_near'] == 'near me':
         
        message_text = "Near by search results"
    else:
        message_text = "Search available rooms based on city location"    

    bot.send_message(chat_id, message_text, reply_markup=menu_markup)


def back_to_editing(chat_id):

    if 'account_registration' in Globals.user[chat_id]['manage']:
        Function_call.ask_question(chat_id,9,True)
        Helper.append(chat_id,'Leave','🔙Back',"➡️ Skip")
        Helper.markup(chat_id,"edit account information ","edit account information ","edit account information ", Button.show_buttons(["🔙Back", "Leave","➡️ Skip"]))

    elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Helper.markup(chat_id,"edit room information ","edit room information ","edit room information ", Button.show_buttons(["🔙Back", "Leave","➡️ Skip"],"Sign out"))
        Globals.user[chat_id]['manage']['account_sign_in']['image editor'] = True # if user change image remove old one instead of append
        Function_call.ask_room_questions(chat_id, 4)
        Helper.append(chat_id,'Leave','🔙Back',"➡️ Skip")

    elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        Function_call.ask_question(chat_id,9)
        Helper.append(chat_id,'Leave','🔙Back','➡️ Skip')

    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['image editor'] = True     
        Function_call.ask_room_questions(chat_id, 4)
        Helper.append(chat_id,'Leave','🔙Back','➡️ Skip')
        
    Helper.remove(chat_id,'🚫 cancel','✅ Done','Back to editing')
    Globals.user[chat_id]['button_semaphore'] = "text"



def Skip(chat_id):
    

    if 'account_registration' in Globals.user[chat_id]['manage']:
        current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        Function_call.ask_question(chat_id, current_question + 1)

    elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        Function_call.ask_room_questions(chat_id, current_question + 1)

    elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        skip_edited_user_info(chat_id)
    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        skip_edited_room(chat_id)



def skip_edited_user_info(chat_id):    
    current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)

    Function_call.ask_question(chat_id, current_question + 1)


def skip_edited_room(chat_id):    
    current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
    
    
    if current_question == 3:
        Globals.user[chat_id]['manage']['account_sign_in']['edit room'][current_question] = Globals.user[chat_id]['manage']['account_sign_in']['room info holder']['image']
    
    Function_call.ask_room_questions(chat_id, current_question + 1)





def No(chat_id):
     

    Globals.user[chat_id]['button_semaphore'] = 0
    markups = telebot.types.ReplyKeyboardRemove()
    bot.send_message(chat_id,"cancelled",reply_markup=markups)
    
    if 'delete room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['delete room'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['delete room']
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))

    elif 'delete account' in Globals.user[chat_id]['manage']['account_sign_in']:
        bot.send_message(chat_id,"Menus",reply_markup=Button.keyboards(chat_id))
        del Globals.user[chat_id]['manage']['account_sign_in']['delete account']
    else:
        Button.buttons(chat_id)

    
    





def back(message):
    
    chat_id = message.chat.id


    if 'account_registration' in Globals.user[chat_id]['manage']:
        current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        if current_question > 1:
            Function_call.ask_question(chat_id, current_question - 1)
        else:
            Globals.user[chat_id]['button_semaphore'] = 1
            markups = telebot.types.ReplyKeyboardRemove()
            bot.send_message(message.chat.id,'back to',reply_markup=markups)
            bot.send_message(chat_id, "Welcome! to room reservation", reply_markup=Button.keboard_manage(chat_id))
            Helper.remove(chat_id,'🔙Back','Leave')

    elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        if current_question > 1:
           
                
            Function_call.ask_room_questions(chat_id, current_question - 1)
        else:
            
            Globals.user[chat_id]['button_semaphore'] = 0
            markups = telebot.types.ReplyKeyboardRemove()
            bot.send_message(message.chat.id,'back to',reply_markup=markups)
            bot.send_message(chat_id, "Managing menu", reply_markup=Button.keyboards(chat_id))
            Helper.remove(chat_id,'🔙Back','Leave')
            

    

    elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)
        if current_question > 1:
            Function_call.ask_question(chat_id, current_question - 1)
        else:
            markups = telebot.types.ReplyKeyboardRemove()
            bot.send_message(message.chat.id,'back to',reply_markup=markups)
            bot.send_message(chat_id, "Welcome! to room reservation", reply_markup=Button.keyboards(chat_id))
            Helper.remove(chat_id,'➡️ Skip','🔙Back','Leave')

    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
       
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
        print("here "+ str(current_question))
        current_question =  current_question - 1
        if current_question > 1:
            Function_call.ask_room_questions(chat_id, current_question)
            Helper.remove(chat_id,'Leave')
        elif current_question == 1:
            menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            menu_markup.row(Button.leave_button)
            common_text = "✏️✏️✏️✏️✏️✏️✏️✏️\n "
            Helper.markup(chat_id,common_text+"please enter the room type you want to edit ",common_text+ "እባክዎን ማረም የሚፈልጉትን የክፍል አይነት ያስገቡ። ",common_text+"please enter the room type you want to edit ",menu_markup)
            Helper.remove(chat_id,'➡️ Skip','🔙Back')
            




def leave(chat_id):
    
 
    if 'account_registration' in Globals.user[chat_id]['manage']:
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " you exit the form", reply_markup=markups)
        
        Globals.user[chat_id]['manage']['account_registration'].clear()
        del Globals.user[chat_id]['manage']['account_registration']
        Helper.markup(chat_id,"Welcome! to room reservation","Welcome! to room reservation","Welcome! to room reservation",Button.keboard_manage(chat_id))
        
    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['edit room'].clear()
        del  Globals.user[chat_id]['manage']['account_sign_in']['edit room']
        
        if 'room info holder' in Globals.user[chat_id]['manage']['account_sign_in']:
            del Globals.user[chat_id]['manage']['account_sign_in']['room info holder']

        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button)
        bot.send_message(chat_id,"left the room editing form", reply_markup = menu_markup)
        Helper.markup(chat_id,"managing menu","managing menu","managing menu",Button.keyboards(chat_id))


    elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " you exit the form", reply_markup=markups)


        Globals.user[chat_id]['manage']['account_sign_in']['edit user'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['edit user']
        del Globals.user[chat_id]['manage']['account_sign_in']['account info holder']

        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button)
        bot.send_message(chat_id,"signed out",reply_markup=menu_markup)
        Helper.markup(chat_id,"Welcome! to room reservation","Welcome! to room reservation","Welcome! to room reservation",Button.keyboards(chat_id))
        

    elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " you exit the form", reply_markup=markups)


        Globals.user[chat_id]['manage']['account_sign_in']['add room'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['add room']

        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button)
        bot.send_message(chat_id,"back to",reply_markup=menu_markup)
        Helper.markup(chat_id,"Welcome! to room reservation","Welcome! to room reservation","Welcome! to room reservation",Button.keyboards(chat_id))
   

    elif 'delete room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['delete room'].clear()
        del  Globals.user[chat_id]['manage']['account_sign_in']['delete room']

        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button)
        bot.send_message(chat_id,"back to", reply_markup = menu_markup)
       
        Helper.markup(chat_id,"managing menu","managing menu","managing menu",Button.keyboards(chat_id))

    elif 'delete account' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.delete_account[chat_id].clear()
        del  Globals.delete_account[chat_id]

        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button)
        bot.send_message(chat_id,"back to", reply_markup = menu_markup)
        Helper.markup(chat_id,"managing menu","managing menu","managing menu",Button.keyboards(chat_id))


    elif 'account_sign_in' in Globals.user[chat_id]['manage']:
  
        Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " you exit the form", reply_markup=markups)

        Globals.user[chat_id]['manage']['account_sign_in'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']
        
        Helper.markup(chat_id,"Welcome! to room reservation","Welcome! to room reservation","Welcome! to room reservation",Button.keboard_manage(chat_id))







