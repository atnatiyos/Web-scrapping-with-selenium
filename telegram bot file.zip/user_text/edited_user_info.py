
import telebot
import Globals

import Button
from telebot import types
import Function_call
import Helper
import Database
import API


bot = telebot.TeleBot(API.API_KEY)

def edited_user_info(message):
    chat_id = message.chat.id


    current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)
    if current_question is not None:

        if current_question == 3 and message.content_type == 'location':
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
            Function_call.ask_question(chat_id, current_question + 1)

        elif current_question == 8 and message.content_type == 'photo':
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
            Function_call.ask_question(chat_id, current_question + 1)

            #handling text inputs in the user registration  form
        elif current_question != 3 and current_question != 8 and message.content_type == 'text':
            # handling validity of the email address

            if current_question == 7:
                if Helper.is_valid_email(message.text):
                    Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
                    Function_call.ask_question(chat_id, current_question + 1)
                else:
                    bot.send_message(chat_id,"the email is invalid")
                    Function_call.ask_question(chat_id, current_question)
            # handling the validity of the phone number
            elif current_question == 6:
                if Helper.is_valid_phone_number(message.text):
                    Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
                    Function_call.ask_question(chat_id, current_question + 1)
                else:
                    bot.send_message(chat_id,"the phone number is invalid")
                    Function_call.ask_question(chat_id, current_question)
            # check if the user name taken or not
            elif current_question == 4:
                try:
                    query = "SELECT * FROM users where Username = " + "'"+message.text +"'"
                    Database.cursor.execute(query)
                    # Fetch the results
                    rows = Database.cursor.fetchall()
                    if(rows):
                        # user name already exist
                        bot.send_message(chat_id,"user name is already taken use other username")
                        Function_call.ask_question(chat_id, current_question)
                    else:
                        Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
                        Function_call.ask_question(chat_id, current_question + 1)
                           
                except Exception as e:
                    print(f"Retrieve failed: {str(e)}")
                    #bot.send_message(chat_id,"something went wrong restarting the registration")
                    bot.send_message(message.chat.id, "something went wrong restarting the registration", reply_markup=Button.keboard_manage(chat_id))

            elif current_question == 2:
                
                #check if it is not editing other info rather than the name
                if Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question-1] == Globals.user[chat_id]['manage']['account_sign_in']['account info holder']['hotel_name'] and message.text == Globals.user[chat_id]['manage']['account_sign_in']['account info holder']['city_location']:
                    print("the same")
                    Function_call.ask_question(chat_id, current_question + 1)
                    return

                query = "select Users_id, Hotel_name from users where Hotel_name = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question-1]) + "' and City_location = '" + message.text + "'"
                

                try:
                    
                    Database.cursor.execute(query)
                    result = Database.cursor.fetchall()
                    print(result)
                    if len(result):
                        bot.send_message(message.chat.id,"the same hotel or motel name is already registered use a different name or contact us if the name is taken by different user")
                        Function_call.ask_question(chat_id,  1)
                    else:
                        Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
                        Function_call.ask_question(chat_id, current_question + 1)
                except Exception as e:
                    print(e)
                    bot.send_message(chat_id,"some thing went wrong")
                    Function_call.ask_question(chat_id, current_question)

            else:
                Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.text
                Function_call.ask_question(chat_id, current_question + 1)

        else:
            bot.send_message(chat_id, "Please enter the correct information")
            Function_call.ask_question(chat_id, current_question)


    else:
        bot.send_message(chat_id, "For adding different user you can signup again.")