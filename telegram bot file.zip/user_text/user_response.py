
import telebot
import Globals

from telebot import types
import Function_call

import Database
import API


bot = telebot.TeleBot(API.API_KEY)

def user_response(message):
    chat_id = message.chat.id
    current_question =  Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        
        
    if current_question is not None:
        #handling inserting image of the rooms
        if current_question == 3 and message.content_type == 'photo':
            Globals.user[chat_id]['manage']['account_sign_in']['add room'][current_question] = message.text
            Function_call.ask_room_questions(chat_id, current_question + 1)

            #handling the other text inputs
        elif current_question != 3 and message.content_type == 'text':
            # handle wether the text is numeric or alphabetical
            if current_question == 2 or current_question == 4:
                    if  current_question == 4:
                        try:
                            del Globals.user[chat_id]['manage']['account_sign_in']['add room']['image album id holder']
                        except:
                            print("error message due to no image album id holder")
                    input = message.text
                    if input.isdigit():
                       
                        Globals.user[chat_id]['manage']['account_sign_in']['add room'][current_question] = message.text
                        Function_call.ask_room_questions(chat_id, current_question + 1)
                        
                    else:
                        bot.reply_to(chat_id, "you should enter a numeric value")
                        Function_call.ask_room_questions(chat_id, current_question)
                    #bot.reply_to(message, f"You entered a numeric value: {numeric_value}")
                

            else:
                input = message.text
                if input.isdigit():
                    numeric_value = float()

                    bot.reply_to(message, "you should enter an alphabet value")
                    Function_call.ask_room_questions(chat_id, current_question)
                    #bot.reply_to(message, f"You entered a numeric value: {numeric_value}")
                else:
                    # If it's not a numeric value, it's a text-based command
                        
                    # accept room type but room type should not duplicate
                    if current_question == 1:
                        # check weather the room type exist or not
                        query = "SELECT * from Rooms where room_type = '"+ str(message.text) +"' and Hotel_id = (SELECT Users_id from users where Username = '"+  str(Globals.user[chat_id]['manage']['account_sign_in']['username']) +"');"

                        try:
                            Database.cursor.execute(query)
                            # Fetch the results
                            rows = Database.cursor.fetchall()
                                
                            if(rows):
                                bot.send_message(chat_id,"room type already exist used edit room option for changing room properties")
                                Function_call.ask_room_questions(chat_id, 1)
                                
                                
                            else:
                                Globals.user[chat_id]['manage']['account_sign_in']['add room'][current_question] = message.text
                                Function_call.ask_room_questions(chat_id, 2)
                                
                        except Exception as e:
                            print(f"Retrieve failed: {str(e)}")
                            bot.send_message(chat_id,"something went wrong with the form ")

                        




        else:
            bot.send_message(chat_id, "Please reply with the correct answer format")
            Function_call.ask_room_questions(chat_id, current_question)

    else:
        bot.send_message(chat_id, "Please start the progrma wit /start.")