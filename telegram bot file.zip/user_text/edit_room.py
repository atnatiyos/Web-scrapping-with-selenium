
import telebot
import Globals

from telebot import types
import Function_call

import Database
import API


bot = telebot.TeleBot(API.API_KEY)

def edit_room(message):
    chat_id = message.chat.id
    current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
    print(current_question)
    if current_question is not None:
        #handling inserting image of the rooms
        if current_question == 3 and message.content_type == 'photo':
            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][current_question] = message.text
            Function_call.ask_room_questions(chat_id, current_question + 1)

            #handling the other text inputs
        elif current_question != 3 and message.content_type == 'text':
            # handle wether the text is numeric or alphabetical
            if current_question == 2 or current_question == 4:
                try:
                    numeric_value = float(message.text)
                   
                        
                    Globals.user[chat_id]['manage']['account_sign_in']['edit room'][current_question] = message.text
                    Function_call.ask_room_questions(chat_id, current_question + 1)
                    return
                    #bot.reply_to(message, f"You entered a numeric value: {numeric_value}")
                except ValueError:
                    # If it's not a numeric value, it's a text-based command
                    bot.reply_to(message, "you should enter a numeric value")
                    Function_call.ask_room_questions(chat_id, current_question)

            else:
                
                  
                    # accept room type but room type should not duplicate
                    if current_question == 1:
                        # check weather the room type exist or not
                        query = "SELECT Room_type,Room_price,Room_picture,Number_of_rooms from Rooms where room_type = '"+ message.text+"' and Hotel_id = (SELECT Users_id from users where Username = '"+  str(Globals.user[chat_id]['manage']['account_sign_in']['username']) +"');"
                        try:
                            Database.cursor.execute(query)
                            # Fetch the results
                            rows = Database.cursor.fetchall()
                            print(rows)
                            # index = 1
                            # for row in rows:
                            #     Globals.user[chat_id]['manage']['account_sign_in']['edit room'][index] =  row[index - 1]
                            #     index = index + 1
                            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1] = rows[0][0]
                            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][2] = rows[0][1]
                            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3] = rows[0][2]
                            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][4] = rows[0][3]
                            print(Globals.user[chat_id]['manage']['account_sign_in']['edit room'])
                            #Globals.edited_room_form[chat_id] = rows
                            
                            Globals.user[chat_id]['manage']['account_sign_in']['room info holder'] = {"image":rows[0][2]}
                            print(Globals.user[chat_id]['manage']['account_sign_in']['room info holder'])
                                
                            if(len(rows)):
                                # Globals.editing[chat_id] = False
                                #Globals.user[chat_id]['manage']['account_sign_in']['edit room'][current_question] = message.text
                                Function_call.ask_room_questions(chat_id, current_question + 1)
                                   
                            else:
                                bot.send_message(chat_id,"room type does not exist ")
                                Function_call.ask_room_questions(chat_id, current_question)
                                    
                        except Exception as e:
                            print(f"Retrieve failed: {str(e)}")
                            bot.send_message(chat_id,"something went wrong ")

                    
        else:
            bot.send_message(chat_id, "Please reply with the correct answer format")
            Function_call.ask_room_questions(chat_id, current_question)

    else:
        bot.send_message(chat_id, "Please start the questionnaire using /start.")