
from email import message
from subprocess import call
from time import sleep

import telebot

from telebot import types
import requests

import signal
import schedule
import threading
import time
from datetime import datetime, timedelta
from requests.exceptions import ConnectTimeout





import Globals
import Helper
import Button
import Function_call
import Location_handler
import Photo_handler
import Text_handler
import Database
import Keyboard_button
import API
import Function_call_search
import initialize
import detail
import inactive_users





from keyboardButton import yes
from keyboardButton import done
from inline_button_handle import inline_button
#from inline_button_handle import detail

import requests

# Set the timeout globally for the requests library
requests.packages.urllib3.disable_warnings()  # Disable SSL warnings (optional)
requests.adapters.DEFAULT_RETRIES = 10  # Retry a few times on connection errors
requests.adapters.DEFAULT_TIMEOUT = 60  # Set the default timeout to 30 seconds

#

bot = telebot.TeleBot(API.API_KEY)




@bot.message_handler(commands=['start'] )
def start(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    initialize.user_id_initialize(chat_id)
    Globals.user[chat_id]['time'] = datetime.now()

    if "manage" in Globals.user[chat_id]:
        del Globals.user[chat_id]['manage']
    elif 'search room' in Globals.user[chat_id]:
        del Globals.user[chat_id]['search room']

    Helper.remove_inline_button(chat_id, Globals.user[chat_id]['message_id'])
    markups = telebot.types.ReplyKeyboardRemove()  
    delete_message = bot.send_message(chat_id,"telegram room finder",reply_markup=markups)
    bot.delete_message(chat_id,delete_message.message_id)

    message = "This telegram bot shows hotel or motel rooms, their prices and where it located you can start by using the menu"
    Helper.markup(chat_id,message,message,message,Button.options() )
    
    
@bot.callback_query_handler(func=lambda call: call.data == "search") 
def search(call):
    chat_id = call.from_user.id
    bot.edit_message_reply_markup(chat_id,call.message.message_id,reply_markup=None)
    inline_button.room_search(chat_id) 


@bot.callback_query_handler(func=lambda call: call.data == "manage") 
def search(call):
    chat_id = call.from_user.id
    bot.edit_message_reply_markup(chat_id,call.message.message_id,reply_markup=None)
    inline_button.manage_account(chat_id) 


@bot.message_handler(commands=['languages'])
def language(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    initialize.user_id_initialize(chat_id)
    Globals.user[chat_id]['time'] = datetime.now()

    if "manage" in Globals.user[chat_id]:
        del Globals.user[chat_id]['manage']
    elif 'search room' in Globals.user[chat_id]:
        del Globals.user[chat_id]['search room']

    markups = telebot.types.ReplyKeyboardRemove()
    delete_message = bot.send_message(chat_id,"Language options",reply_markup=markups)
    bot.delete_message(chat_id,delete_message.message_id)

    languages(chat_id)




    
def languages(chat_id):
    Helper.remove_inline_button(chat_id, Globals.user[chat_id]['message_id'])      
    lookup_query = " select User_TelegramID from UserId where User_TelegramID = '" + str(chat_id) + "'"
    try:
        Database.cursor.execute(lookup_query)
        result = Database.cursor.fetchall()
            
        if len(result) == 0:
            userId_query = "Insert into UserId (User_TelegramId,Languages) values ('"+str(chat_id)+"','english')"
            Database.cursor.execute(userId_query)
            Database.conn.commit()
            Globals.user[chat_id]['language'] = 'english'
    except Exception as e:
        print(f"Retrieve failed: {str(e)}")
        Helper.markup(chat_id,"Sorry!! something went wrong","አዝናለሁ!! የሆነ ስህተት ተከስቷል","Sorry!! something went wrong",None)

    Helper.markup(chat_id,"Select a language","ቋንቋ ይምረጡ","Select a language",Button.language)


    
@bot.message_handler(commands=['search'])
def search_available_room(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    initialize.user_id_initialize(chat_id)
    Globals.user[chat_id]['time'] = datetime.now()
    
    
    if 'manage' not in Globals.user[chat_id]:
        inline_button.room_search(chat_id)
        return


    if 'account_registration' in Globals.user[chat_id]['manage'] or ('account_sign_in' in Globals.user[chat_id]['manage'] and 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']):
        Helper.markup(chat_id,"*please first leave the user hotel infromation form*","*እባክዎ መጀመሪያ የተጠቃሚውን የሆቴል መረጃ ቅጽ ለቀው ይውጡ*","*please first leave the user hotel infromation form*",None)

        current_question = None
        if 'account_registration' in Globals.user[chat_id]['manage']:
            current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        else:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)

        Function_call.ask_question(chat_id, current_question)
        return
    elif ('account_sign_in' in Globals.user[chat_id]['manage'] and  'add room' in Globals.user[chat_id]['manage']['account_sign_in']) or ('account_sign_in' in Globals.user[chat_id]['manage'] and 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']):
        Helper.markup(chat_id,"*please first leave the room infromation form*","*እባክዎ መጀመሪያ የተጠቃሚውን የሆቴል መረጃ ቅጽ ለቀው ይውጡ*","*please first leave the room infromation form*",None)


        current_question = None
        if 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        else:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
        Function_call.ask_room_questions(chat_id, current_question)
        return
    else:
        
        del Globals.user[chat_id]['manage']
        inline_button.room_search(chat_id)
        


    

@bot.message_handler(commands=['manage'])
def search_available_room(message):
    chat_id  = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    initialize.user_id_initialize(chat_id)
    Globals.user[chat_id]['time'] = datetime.now()

    Globals.user[chat_id]['manage'] = {}

    if 'search room' in Globals.user[chat_id]:
        del Globals.user[chat_id]['search room']
 
    if 'account_registration' in Globals.user[chat_id]['manage'] or ( 'account_sign_in' in Globals.user[chat_id]['manage'] and 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']):
        

        Helper.markup(chat_id,"*please first leave the user hotel infromation form*","*እባክዎ መጀመሪያ የተጠቃሚውን የሆቴል መረጃ ቅጽ ለቀው ይውጡ*","*please first leave the user hotel infromation form*",None)


        current_question = None
        if 'account_registration' in Globals.user[chat_id]['manage']:
            current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        else:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)

        Function_call.ask_question(chat_id, current_question)
        return
    elif 'account_sign_in' in Globals.user[chat_id]['manage'] and 'add room' in Globals.user[chat_id]['manage']['account_sign_in'] or  'account_sign_in' in Globals.user[chat_id]['manage'] and 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
       
        Helper.markup(chat_id,"*please first leave the room infromation form*","*እባክዎ መጀመሪያ የተጠቃሚውን የሆቴል መረጃ ቅጽ ለቀው ይውጡ*","*please first leave the room infromation form*",None)


        current_question = None
        if 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        else:
            current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
        Function_call.ask_room_questions(chat_id, current_question)
        return
    else:             
        inline_button.manage_account(chat_id)
        

 





############### sign up for a new account################
@bot.callback_query_handler(func=lambda call: call.data == "sign up")
def sign_up_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return


    try:        
        inline_button.signup(chat_id,call.message.message_id)
    except Exception as e:
        print(e)
        Helper.markup(chat_id,"sign up for creating a new account or sign in if account already exist","አዲስ መለያ ለመፍጠር ይመዝገቡ ወይም መለያ ቀድሞውኑ ካለ ይግቡ","sign up for creating a new account or sign in if account already exist",Button.keboard_manage(chat_id))




@bot.callback_query_handler(func=lambda call: call.data == "sign in")
def sign_in_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Globals.user[chat_id]['button_semaphore'] = 0
    
    try:
   
        inline_button.signin(chat_id,call.message.message_id)
    except Exception as e:
        print(e)
        Helper.markup(chat_id,"sign up for creating a new account or sign in if account already exist","አዲስ መለያ ለመፍጠር ይመዝገቡ ወይም መለያ ቀድሞውኑ ካለ ይግቡ""sign up for creating a new account or sign in if account already exist",Button.keboard_manage(chat_id))





@bot.callback_query_handler(func=lambda call: call.data.startswith('detail_'))
def button_callback(callback_query):
    Globals.user[callback_query.from_user.id]['time'] = datetime.now()

    detail.detail(callback_query)



@bot.callback_query_handler(func=lambda call: call.data == "forget password")
def forget_password_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    Globals.user[chat_id]['button_semaphore'] = 0

    if initialize.check_program(chat_id):
        return

    Helper.remove_inline_button(chat_id,call.message.message_id)
    
    query = "select Hotel_name, Username, User_password from users where Telegram_id = '" + str(chat_id) + "';"
    print(query)

    try:
        Database.cursor.execute(query)
        rows = Database.cursor.fetchall()

        
        print(rows[0])
        if len(rows) == 0:
            Helper.markup(chat_id,"No account is registered with this telegram account \n sign up to create a new account ","በዚህ የቴሌግራም አካውንት ምንም መለያ አልተመዘገበም \n አዲስ መለያ ለመፍጠር ይመዝገቡ","No account is registered with this telegram account \n sign up to create a new account ",Button.keyboards(chat_id))
        else:
            
            info = str(len(rows)) + " accounts found \n"
            for row in rows:
                password = Helper.decrypt(str(row[2]).encode('utf-8'))
                info = info +  " Hotel name  " + str(row[0]) + "  Username " +str(row[1])+ " Password " + str(password) + "\n\n"
                
            bot.send_message(chat_id,info)
    except:
        Helper.markup(chat_id,"something went wrong","የሆነ ስህተት ተከስቷል","something went wrong",Button.keyboard(chat_id))



@bot.callback_query_handler(func=lambda call: call.data == "credential")
def credential_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Helper.markup(chat_id,"login using your credential","የይለፍ ቃልህን ተጠቅመህ ግባ","login using your credential")
    Helper.remove_inline_button(chat_id,call.message.message_id)
    Globals.user[chat_id]['button_semaphore'] = "text"
    Function_call.login_question(chat_id, 1)

@bot.callback_query_handler(func=lambda call: call.data == "telegram")
def telegram_login(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Globals.user[chat_id]['button_semaphore'] = 0

    Helper.remove_inline_button(chat_id,call.message.message_id)
    query  = "select Username, user_password from users where Telegram_id = " + str(chat_id) + ";"
    try:
        Database.cursor.execute(query)

        row = Database.cursor.fetchall()

        
        if len(row) > 1:
            Helper.markup("Telegram id registerd in multiple account please use the credentials based login","የቴሌግራም መታወቂያ በብዙ መለያ ተመዝግቧል እባኮትን በመረጃዎች ላይ የተመሰረተ መግቢያ ይጠቀሙ","Telegram id registerd in multiple account please use the credentials based login",Button.credential_login(chat_id))

        elif len(row) == 1:
            Globals.user[chat_id]['manage']['account_sign_in']['username'] = row[0][0]
            Globals.user[chat_id]['manage']['account_sign_in']['password'] = row[0][1]

            Function_call.Load_user_info(chat_id)

            
        else:
            Helper.markup(chat_id,"sorry no account register with this telegram id","ይቅርታ በዚህ የቴሌግራም መታወቂያ ምንም መለያ መመዝገቢያ የለም","sorry no account register with this telegram id",None)
        
    except Exception as e:
        print(f"Retrieve failed: {str(e)}")

        Helper.markup(chat_id,"something went wrong ","የሆነ ችግር ተፈጥሯል ","something went wrong ",Button.keboard_manage(chat_id))

        

@bot.callback_query_handler(func=lambda call: call.data == "add room")
def add_room_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    
    

    
    Globals.user[chat_id]['button_semaphore'] = "text"  
    inline_button.add(chat_id,call.message.message_id)


@bot.callback_query_handler(func=lambda call: call.data == "edit room")
def edit_room_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Globals.user[chat_id]['button_semaphore'] = "text"
    inline_button.edit_room(chat_id,call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "delete Room")
def delet_room_handler(call):
    chat_id = call.from_user.id 
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    Globals.user[chat_id]['button_semaphore'] = 0 
    inline_button.delete_room(chat_id,call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "edit user")
def edit_user_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Globals.user[chat_id]['button_semaphore'] = 0
    inline_button.edit_user(chat_id,call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "show rooms")
def show_rooms_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    

    Globals.user[chat_id]['button_semaphore'] = 0  
    inline_button.show_rooms(chat_id,call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "search room")
def search_room_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return    

    Globals.user[chat_id]['button_semaphore'] = 0    
    inline_button.room_search(chat_id,call.message.message_id)
    

    

@bot.callback_query_handler(func=lambda call: call.data == "search by city")
def search_city_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    
    Helper.append(chat_id,'Back to search')
    Globals.user[chat_id]['button_semaphore'] = "text"
    Globals.user[chat_id]['search room']['search by'] = {"name_or_near":"city",'search property':{}}
    Function_call_search.by_city(chat_id,call.message.message_id)



@bot.callback_query_handler(func=lambda call: call.data == "near me")
def near_me_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    
    Helper.append(chat_id,'Back to search')
    Globals.user[chat_id]['button_semaphore'] = "location"
    Globals.user[chat_id]['search room']['search by'] = {"name_or_near": "near me", 'search property': {}}
    Function_call_search.near_me(chat_id,call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "all")
def all_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    
    
    Globals.user[chat_id]['search room']['offset'] = 0
    Globals.user[chat_id]['button_semaphore'] = 0
    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "all"
    
    if Globals.user[chat_id]['search room']['search by']['name_or_near'] == "near me":
        Helper.markup(chat_id,"near by search rooms","በመፈለጊያ ክፍሎች አቅራቢያ","near by search rooms",Button.show_buttons(["filter by","all"],"Back to search"))
        Location_handler.get_hotels(chat_id,Globals.user[call.from_user.id]['search room']['search by']['search property']['city_name'],Globals.user[chat_id]['search room']['search by']['search property']['content'].location.latitude,Globals.user[chat_id]['search room']['search by']['search property']['content'].location.longitude,call.message.message_id)
        
        return    
    Function_call_search.all(chat_id,call.message.message_id)

    Helper.append("filter by")
    Helper.remove("all")

@bot.callback_query_handler(func=lambda call: call.data == "filter price")
def filter_price_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    
    Globals.user[chat_id]['button_semaphore'] = "text"
    Globals.user[chat_id]['search room']['offset'] = 0

    if Globals.user[chat_id]['search room']['search by']['name_or_near'] == 'near me':
        Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",Button.show_buttons(["filter by","all"],"Back to search"))  

        
        return
    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "price"   
    Function_call_search.by_price(chat_id,call.message.message_id)
    Helper.append("all")
    Helper.remove("filter by")


@bot.callback_query_handler(func=lambda call: call.data == "specific")
def specific_search(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()

    

    Globals.user[chat_id]['button_semaphore'] = 'text'
    bot.send_message(chat_id, "please enter the hotel or motel name ")
    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "specific"
    if Globals.user[chat_id]['message_id'] != None:
        
        bot.edit_message_reply_markup(chat_id,message_id=Globals.user[chat_id]['message_id'],  reply_markup=None)
        Globals.user[chat_id]['message_id'] = None

@bot.callback_query_handler(func=lambda call: call.data == "net point")
def net_point(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()

    bot.send_message(chat_id, "please select the net point ")
    Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])
    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "net point"
    markup = Button.net_point(chat_id,Globals.user[chat_id]['search room']['search by']['search property']['city name']) 
    bot.send_message(chat_id, "net point:", reply_markup=markup)
    
@bot.callback_query_handler(func=lambda call: call.data == "more")
def more_handler(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return
    

    Globals.user[chat_id]['search room']['offset'] = Globals.user[chat_id]['search room']['offset'] + 5
    if Globals.user[chat_id]['search room']['search by'] == 'near me':
 
        Location_handler.get_hotels(chat_id,Globals.user[chat_id]['search room']['search by']['search property']['city_name'],Globals.user[chat_id]['search room']['search by']['search property']['content'].location.latitude,Globals.user[chat_id]['search room']['search by']['search property']['content'].location.longitude,call.message.message_id)
        return

    if Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "all":
        Function_call_search.all(chat_id,call.message.message_id)

    elif Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "net point":
        Helper.remove_inline_button(chat_id,call.message.message_id)
        Function_call_search.net_point(chat_id)   

    elif Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "price":
        Function_call.price_filter(chat_id,Globals.user[chat_id]['search room']['search by']['search property']['price range'],call.message.message_id)
        


@bot.callback_query_handler(func=lambda call: call.data == "delete account")  
def delete_account(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        return

    Globals.user[chat_id]['manage']['account_sign_in']['delete account'] = {}
    bot.edit_message_reply_markup(chat_id=chat_id,message_id=call.message.message_id,  reply_markup=None)

  
    Button.confirm(chat_id)


############### Change to preferd language
@bot.callback_query_handler(func=lambda call: call.data == "english")  
def English(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    try:
        userId_query = "UPDATE UserId set Languages = '"+str(call.data)+"' where User_TelegramId = '"+str(chat_id)+"'"
        
        Database.cursor.execute(userId_query)
        Database.conn.commit()
        Globals.user[chat_id]['language'] = 'english'
        bot.send_message(chat_id,"Language set to English")
        Helper.remove_inline_button(chat_id,call.message.message_id)
        
    except Exception as e:
        print(e)
        bot.send_message(chat_id,"sorry something went wrong please select language again")


@bot.callback_query_handler(func=lambda call: call.data == "affan oromo")  
def English(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    try:
        userId_query = "UPDATE UserId set Languages = '"+str(call.data)+"' where User_TelegramId = '"+str(chat_id)+"'"
        Database.cursor.execute(userId_query)
        Database.conn.commit()
        Globals.user[chat_id]['language'] = 'affan oromo'
        bot.send_message(chat_id,"Language set to Affan oromo")
        Helper.remove_inline_button(chat_id,call.message.message_id)
        
    except:
        print("something not wright")
        bot.send_message(chat_id,"sorry something went wrong please select language again")


@bot.callback_query_handler(func=lambda call: call.data == "amharic")  
def English(call):
    chat_id = call.from_user.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    try:
        userId_query = "UPDATE UserId set Languages = '"+str(call.data)+"' where User_TelegramId = '"+str(chat_id)+"'"
        Database.cursor.execute(userId_query)
        Database.conn.commit()
        Globals.user[chat_id]['language'] = 'amharic'
        bot.send_message(chat_id,"የቋንቋ ለውጥ ወደ አማርኛ ተቀየረ")
        Helper.remove_inline_button(chat_id,call.message.message_id)
        
    except:
        print("something not wright")
        bot.send_message(chat_id,"sorry something went wrong please select language again")

##### edit user information in time of sign up###########



@bot.message_handler(func=lambda message: message.text == "Sign out")
def sign_out(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return

    if 'manage' in Globals.user[chat_id] and 'account_sign_in' in Globals.user[chat_id]['manage']:
        
        Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])        
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id,'signed out',reply_markup=markups)
        Helper.markup(chat_id,"sign up/sign in","እንኳን በደህና መጡ! ወደ ክፍል ማስያዣ","sign up/sign in",Button.keboard_manage(chat_id))

        Globals.user[chat_id]['inline keyboard'] = []
        
    else:
        markups = telebot.types.ReplyKeyboardRemove()
        Helper.markup(chat_id,"first you should sign in","መጀመሪያ መግባት አለብህ","first you should sign in",markups)
  





@bot.message_handler(func=lambda message: message.text == "Leave")
def Leave(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    print(Globals.user[chat_id]['inline keyboard'])
    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
    else:
        Helper.remove(chat_id,'Leave')
        Keyboard_button.leave(chat_id)

    


@bot.message_handler(func=lambda message: message.text == "❌ No")
def handle_option1(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
        return
    
   
    Helper.append(chat_id,'🚫 cancel')
    Helper.remove(chat_id,'✔️ Yes','❌ No')
    Keyboard_button.No(chat_id)


# back button used to go to the previous form
@bot.message_handler(func=lambda message: message.text == "🔙Back")
def back(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    Keyboard_button.back(message)
   
        
@bot.message_handler(func=lambda message: message.text == "Back to search")
def handle_option1(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()

    del Globals.user[chat_id]['search room']['search by']

    Globals.user[chat_id]['button_semaphore'] = 0
    Globals.user[chat_id]['search room']['offset'] = 0    

    
    

    markups = telebot.types.ReplyKeyboardRemove()
    Helper.markup(chat_id," Back to search "," ወደ ፍለጋ ተመለስ  "," Back to search ",markups)
    Helper.markup(chat_id,"Search for rooms based on","ክፍሎችን ፈልግ","Search for rooms based on",Button.keyboard_filter(chat_id))
    Helper.remove(chat_id,'Back to search')


# handle cancel button by asking for confermation
@bot.message_handler(func=lambda message: message.text == "🚫 cancel")
def handle_option1(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):   
        return
    
    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
        return
    
    Globals.user[chat_id]['button_semaphore'] = 0
    bot.send_message(chat_id, "are you sure you want to cancel")
    Button.confirm(chat_id)
   


# handle finishing user registration form
@bot.message_handler(func=lambda message: message.text == "✅ Done")
def handle_option1(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
        return
   
    done.Done(chat_id)
    
    
    


# confirm cancelation
@bot.message_handler(func=lambda message: message.text == "✔️ Yes")
def handle_option1(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
        return
    
   

    Helper.remove(chat_id,'🚫 cancel','✅ Done','Back to editing','✔️ Yes')
    
    yes.Yes(chat_id)


# skip the qustion
@bot.message_handler(func=lambda message: message.text == "➡️ Skip")
def skip_question(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return
    Keyboard_button.Skip(chat_id)

@bot.message_handler(func=lambda message: message.text == "Back to editing")
def handle_option1(message):
    chat_id = message.chat.id

    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    

    if message.text not in Globals.user[chat_id]['inline keyboard']:
        bot.send_message(chat_id,"you cant use this key at this time")
        return
    
    Keyboard_button.back_to_editing(chat_id)
   
@bot.message_handler(func=lambda message: message.text == "all")
def all_rooms(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    Globals.user[chat_id]['button_semaphore'] = 0

    if initialize.check_program(chat_id):
        
        return
    
    

    Globals.user[chat_id]['search room']['offset'] = 0

    if Globals.user[chat_id]['search room']['search by']["name_or_near"] == "near me":
        Helper.markup(chat_id,"near by search rooms","በመፈለጊያ ክፍሎች አቅራቢያ","near by search rooms",Button.show_buttons(["filter by","all"],"Back to search"))
        Location_handler.get_hotels(chat_id,Globals.user[chat_id]['search room']['city_name'],Globals.user[chat_id]['search room']['content'].location.latitude,Globals.user[chat_id]['search room']['content'].location.longitude,None)
        
        return


    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "all"
    Function_call_search.all(chat_id,None)
    Helper.append("filter by")
    Helper.remove("all")

@bot.message_handler(func=lambda message: message.text == "filter by")
def filter_room_prices(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    if initialize.check_program(chat_id):
        
        return

    Globals.user[chat_id]['button_semaphore'] = "text"
    Globals.user[chat_id]['search room']['offset'] = 0

    if Globals.user[chat_id]['search room']['search by']["name_or_near"] == "near me":
        Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",Button.show_buttons(["filter by","all"],"Back to search"))  
        return
    

    Globals.user[chat_id]['search room']['search by']['search property']['search_based'] = "price"
    Function_call.price_filter(chat_id,message.text,None)
    Helper.append("all")
    Helper.remove("filter by")



@bot.message_handler(func=lambda message: True)
def handle_response(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()

    if initialize.check_program(chat_id): 
        return
    
    if Globals.user[chat_id]['button_semaphore'] == 0:
        bot.send_message(chat_id,"Please use the buttons")
        return

    elif Globals.user[chat_id]['button_semaphore'] != "text":
        bot.send_message(chat_id,"sorry text is not acceptable rigth now")
        return


    
    Text_handler.handle_response(message)


#handle Images for the hotel
@bot.message_handler(content_types=['photo'])
def handle_images(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    
    initialize.check_program(chat_id)
    if Globals.user[chat_id]['button_semaphore'] == 0:
        bot.send_message(chat_id,"Please use the buttons")
        return
    elif 'account_sign_in' in Globals.user[chat_id]['manage']   :
        if 'edit room' in Globals.user[chat_id]['manage']['account_sign_in'] and 4 == Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None):
            Globals.user[chat_id]['manage']['account_sign_in']['edit room']['current_question'] = 3
            print("exception for this case untill it solved")

        elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in'] and 4 == Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None):
            Globals.user[chat_id]['manage']['account_sign_in']['add room']['current_question'] = 3
            print("exception for this case untill it solved")

        
    
    elif Globals.user[chat_id]['button_semaphore'] != "photo" :
        bot.send_message(chat_id,"sorry image is not acceptable rigth now")
        return

    Photo_handler.handle_images(message)


#take the GPS coordination of the hotel
@bot.message_handler(content_types=['location'])
def handle_location(message):
    chat_id = message.chat.id
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['time'] = datetime.now()
    
    
    initialize.check_program(chat_id)

    if Globals.user[chat_id]['button_semaphore'] == 0:
        bot.send_message(chat_id,"Please use the buttons")
        return
    if Globals.user[chat_id]['button_semaphore'] != "location":
        bot.send_message(chat_id,"sorry location is not acceptable rigth now")
        return

    Location_handler.handle_location(message)
    
@bot.message_handler(content_types=['video', 'animation'])
def handle_video(message):
    chat_id = message.chat.id
    # file_id = message.video.file_id  # Use 'video' for videos and 'animation' f
    bot.send_message(chat_id, f"Received video/GIF with file_id:")
    
    print("okay this is media")
# file handling
@bot.message_handler(content_types=["document","audio"])
def handle_document(message):
    chat_id = message.chat.id 
    bot.send_chat_action(chat_id, 'typing')
    initialize.check_program(chat_id)
    Globals.user[chat_id]['time'] = datetime.now()
    
    

    if Globals.near_me[chat_id]:
        Helper.markup(chat_id,"please sent location not file","እባክዎ የተላከው ቦታ አይደለም","please sent location not file",None)
        return
   
    try:
        if Globals.user[chat_id.chat.id]['button_semaphore'] == 0:
            return
        else:
            text_message = "please youse the correct format" if Globals.Selected_Language[chat_id] == 'english' else ( "እባክዎ ትክክለኛውን ቅርጸት አቅርበዋል" if Globals.Selected_Language[chat_id] == 'amharic' else "please youse the correct format" )
            bot.send_message(chat_id,text_message)
        #File_handler.handle_document(chat_id)
    except ConnectTimeout as e:
        print(f"Connection timed out: {e}")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")


# def on_terminate(sig, frame):
#     print("Received signal:", sig)
#     # Graceful termination code:
#     schedule.clear()  # Clear pending tasks
#     # Wait for the scheduler thread to finish:
#     scheduler_thread.join()  # Wait for scheduler thread to finish
#     # Additional cleanup if needed:
#     # ... your cleanup code ...
#     exit(0)


# # Start a thread for checking inactive users
# inactive_users_thread = threading.Thread(target=inactive_users.check_inactive_users)
# inactive_users_thread.start()
# schedule.every().minute.do(inactive_users.check_inactive_users)



# def scheduler_thread():
#     while True:
#         schedule.run_pending()
#         time.sleep(30)  # Sleep briefly to avoid high CPU usage

# # Start a thread for the scheduler
# scheduler_thread = threading.Thread(target=scheduler_thread)
# scheduler_thread.start()


# signal.signal(signal.SIGINT, on_terminate)  # Ctrl+C
# signal.signal(signal.SIGTERM, on_terminate)
# # Start the bot polling in the main thread

try:
    bot.infinity_polling()
except Exception as e:
    print(e)




