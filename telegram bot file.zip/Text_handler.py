
import re
import telebot
import Globals

import Button
from telebot import types
import Function_call
import Function_call_search
import Helper
import Database
import API

import Location_handler




from user_text import user_response
from user_text import edit_room
from user_text import user_form
from user_text import edited_user_info




bot = telebot.TeleBot(API.API_KEY)



def handle_response(message):
    
    #global sign_in_up_search
    chat_id = message.chat.id
    
    
    if  'manage' in  Globals.user[chat_id] and 'account_sign_in' in  Globals.user[chat_id]['manage'] and 'add room' in  Globals.user[chat_id]['manage']['account_sign_in'] : #and Globals.more[chat_id]
        
        user_response.user_response(message)
        return

    # edite existing room

    elif 'manage' in  Globals.user[chat_id] and 'account_sign_in' in Globals.user[chat_id]['manage'] and 'edit room' in Globals.user[chat_id]['manage']['account_sign_in'] :
        #del Globals.user[chat_id]['manage']['account_sign_in']['edit room']['image album id holder']
        edit_room.edit_room(message)

    #delete room

    elif 'manage' in  Globals.user[chat_id] and 'account_sign_in' in Globals.user[chat_id]['manage']  and   'delete room' in Globals.user[chat_id]['manage']['account_sign_in']:
        
        Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1] = message.text
        Function_call.delete_room(chat_id, 2)

    # user in the stage of  registration
    elif 'manage' in  Globals.user[chat_id] and 'account_registration' in Globals.user[chat_id]['manage']:
        user_form.user_form(message)


    # edite user information 
    elif 'manage' in  Globals.user[chat_id] and 'account_sign_in' in Globals.user[chat_id]['manage'] and  'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        edited_user_info.edited_user_info(message)



    #handling login credential
    elif 'manage' in  Globals.user[chat_id] and 'account_sign_in' in Globals.user[chat_id]['manage']: #and 'edit user' not in Globals.user[chat_id]['manage']['account_sign_in'] and chat_id not in 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in'].get('current_question', None)
        
        if current_question == 1:
            Globals.user[chat_id]['manage']['account_sign_in']['username'] = message.text
        elif current_question == 2:
            Globals.user[chat_id]['manage']['account_sign_in']['password'] = message.text
        Function_call.login_question(chat_id, current_question + 1)



    #handling customer search parameters
    elif 'search room' in Globals.user[chat_id] :
        

        if Globals.user[chat_id]['search room']['search by']['name_or_near'] == "city":
            
            if  'city name' not in Globals.user[chat_id]['search room']['search by']['search property']:
                Globals.user[chat_id]['search room']['search by']['search property']['city name'] = message.text
                print(Globals.user[chat_id]['search room']['search by']['search property'])
                menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
                menu_markup.row(Button.Back_to_search)
                bot.send_message(chat_id,str( message.text)+" city selected", reply_markup=menu_markup)
                
                query = "select Distinct City_location from users"
                try:
                    Database.cursor.execute(query)
                    cities = Database.cursor.fetchall()

                    print(cities)
                    if message.text.lower() not in [city[0].lower() for city in cities]:

                        bot.send_message(message.chat.id,"no city name found please select from the buttons bellow")
                        Button.city_list(message.chat.id)
                        return
                except Exception as e:
                    print(e)

                Helper.markup(chat_id,"search  hotel and motel rooms based on ","search  hotel and motel rooms based on ","search  hotel and motel rooms based on ",Button.search_room(chat_id))
                Globals.user[message.chat.id]['button_semaphore'] = 0


            elif Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == 'net point':
                Globals.user[chat_id]['search room']['search by']['search property']['net point'] = message.text
                print(Globals.user[chat_id]['search room']['search by']['search property'])
                Function_call_search.net_point(message.chat.id)
                return

            elif Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == 'specific':
                
                Globals.user[chat_id]['search room']['search by']['search property']['hotel name'] = message.text
                Function_call_search.hotel_name(message.chat.id)
                return
            
            elif Globals.user[chat_id]['search room']['search by']['search property']['search_based'] == "price":
                Globals.user[chat_id]['search room']['search by']['search property']['price range'] = message.text
                Function_call.price_filter(message.chat.id,message.text)
                

        elif Globals.user[chat_id]['search room']['search by']['name_or_near'] == 'near me':
            print("un authorized")
            Location_handler.get_hotels(message.chat.id,Globals.user[message.chat.id]['search room']['search by']['search property']['city_name'],Globals.user[message.chat.id]['search room']['search by']['search property']['content'].location.latitude,Globals.user[message.chat.id]['search room']['search by']['search property']['content'].location.longitude,None,message.text)
            Globals.user[chat_id]['search room']['search by']['search property']['price range'] = message.text 
                        
    elif 'account_registration' not in Globals.user[chat_id]['manage'] and 'account_sign_in' not in Globals.user[chat_id]['manage'] and chat_id not in Globals.user[message.chat.id]['search room'] and chat_id not in Globals.user:
        bot.send_message(chat_id, "use the menu to start the program")


