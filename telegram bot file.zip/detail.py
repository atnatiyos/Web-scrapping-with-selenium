#from sys import exception
from email import message
from subprocess import call
from unittest import result
import telebot
import pypyodbc as odbc
from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO
import sys






# import files
import Globals
import Database
import Helper

import API
bot = telebot.TeleBot(API.API_KEY)


def detail(callback_query):
    bot.send_chat_action(callback_query.from_user.id, 'typing')
    # Get the callback data to determine which button was clicked
    callback_data = callback_query.data
    
    # Extract information from the callback data
    if callback_data.startswith("detail_image_"):
        # type = callback_data.split("_")[2]
        room_id = callback_data.split("_")[3]
        room_id = room_id.split(',')
         
        text = ""
        for ids in room_id:
            print(ids)
            if ids == "":
                
                continue
            text = text + "Rooms.room_id = " + str(ids) + " or "

        text = text + " Rooms.room_id = 0"

        query = "SELECT Room_picture, Room_type, Room_price, Users_id, Hotel_name, City_location,Net_point from Rooms Inner JOIN users ON Rooms.Hotel_id = users.Users_id where " + text
        print(query)
        try:
                        
                Database.cursor.execute(query)
                # Fetch the results
                rows = Database.cursor.fetchall()
            
                text_message = rows[0][4] + " located in " + rows[0][5] + " around "  + rows[0][6]
                bot.send_message(callback_query.from_user.id,text_message)
                for row in rows:
                    bot.send_chat_action(callback_query.from_user.id, 'typing')
                    directory = row[0].split('.')
                    directory_path = directory[0]
                    
                    Room_caption =    str(row[4]) + " \n"
                    Room_caption = Room_caption + "🏨 Room type  " +str(row[1]) + "💰  Room price   " +str(format(row[2],',') + " Birr")
                   
                    Helper.show_album(callback_query.from_user.id,directory_path,Room_caption,' images found')       
           
        except Exception as e:
                print(f"Retrieve failed: {str(e)}")
                bot.send_message(callback_query.from_user.id,"sorry could not load room pictures")
                        
        
    elif callback_data.startswith("detail_location_"):
        
        hotel_id = int(callback_data.split("_")[2])
        
        bot.answer_callback_query(callback_query.id, text=f"Locating Hotel {hotel_id}")
  

        query = "SELECT GPS_location_latitude, GPS_location_longitude,Hotel_name from users where Users_id = " + str(hotel_id)

        try:
                       
            Database.cursor.execute(query)
            # Fetch the results
            row = Database.cursor.fetchall()
            
            if(row):
                # print(row)
                bot.send_location(callback_query.from_user.id, row[0][0], row[0][1])  
                text_message = " hotel location" if Globals.user[callback_query.from_user.id]['language'] == 'english' else ( "የሆቴል ቦታ" if Globals.user[callback_query.from_user.id]['language'] == 'amharic' else " hotel location" )   
                bot.send_message(callback_query.from_user.id,row[0][2] + str(text_message)) 
           
        except Exception as e:
            print(f"Retrieve failed: {str(e)}")
            bot.send_message(callback_query.from_user.id," sorry something went wrong could not load location")
