
user = {}   # register user information start of application

# user_location = {}
# more = {}
# editing = {}

   
    

