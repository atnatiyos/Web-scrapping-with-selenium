import telebot
import Globals
import API
import Button





bot = telebot.TeleBot(API.API_KEY)

questions_list = [
        "Name of the hotel?",
        "City where the hotel located?",
        "GPS location",
        "user name",
        "password",
        "your phone number",
        "email address",
        "Hotel or Motel image",
        "Hotel located around"



        # Add more questions as needed
]


room_questions_list = [
        "Type of the room? ",
        "Price of the hotel room ",
        "Picture of the room ",
        "Number of available rooms "
]

def display_responses(chat_id):
    Globals.user[chat_id]['button_semaphore'] = "text"
    responses =  Globals.user[chat_id]['manage']['account_sign_in'].get('add room', {})
    response_message = "Hotel Room information are :\n\n"  if Globals.user[chat_id]['language'] == 'english' else ( "የሆቴል ክፍል መረጃው፦\n\n " if Globals.user[chat_id]['language'] == 'amharic' else " Hotel Room information are :\n\n" )
   
    for question_number, response in responses.items():
        if question_number != 'current_question':
            if question_number == 3:
                pronoun=" is"
                if len(response) > 1:
                    pronoun="s are"
                response_message += f"{question_number} {room_questions_list[question_number-1]} := {len(response)} image{pronoun} selected\n"
                continue

            response_message += f"{question_number} {room_questions_list[question_number-1]} := {response}\n"
            
    bot.send_message(chat_id,response_message)
   


def display_user_responses(chat_id):
    Globals.user[chat_id]['button_semaphore'] = "text"
    responses = Globals.user[chat_id]['manage'].get('account_registration', {})
    response_message = "Hotel information:\n\n"  if Globals.user[chat_id]['language'] == 'english' else ( "የሆቴል  መረጃው፦\n\n " if Globals.user[chat_id]['language'] == 'amharic' else " Hotel information  :\n\n" )
    
    for question_number, response in responses.items():
        if question_number != 'current_question':
            if question_number == 3:
                response_message += f"{question_number} {room_questions_list[question_number-1]} := {len(response)} image is selected\n"
                continue
            response_message += f"{question_number} {questions_list[question_number-1]} := {response}\n"
            
    bot.send_message(chat_id, response_message)

    

def display_edited_user_responses(chat_id):
    Globals.user[chat_id]['button_semaphore'] = 0
    responses = Globals.user[chat_id]['manage']['account_sign_in'].get('edit user', {})
    response_message = "Here are your responses:\n\n"  if Globals.user[chat_id]['language'] == 'english' else ( "የእርስዎ ምላሾች እነሆ፡\n\n" if Globals.user[chat_id]['language'] == 'amharic' else "Here are your responses:\n\n" )
    
    for question_number, response in responses.items():
        if question_number != 'current_question':
            if question_number == 3:
                response_message += f"{question_number} {room_questions_list[question_number-1]} := {len(response)} image is selected\n"
                continue
            response_message += f"{question_number} {questions_list[question_number-1]} := {response}\n"
            
    bot.send_message(chat_id, response_message)


def display_edited_room(chat_id):
    Globals.user[chat_id]['button_semaphore'] = "text"
    responses = Globals.user[chat_id]['manage']['account_sign_in'].get('edit room', {})
    print(responses)
    response_message = "Edited Hotel room information:\n\n" if Globals.user[chat_id]['language'] == 'english' else ("የተስተካከለ የሆቴል ክፍል መረጃ፡\n\n" if Globals.user[chat_id]['language'] == 'amharic' else "Edited Hotel room information:\n\n" )
    
    for question_number, response in responses.items():
        if question_number != 'current_question':
            if question_number == 3:
                pronoun=" is"
                if len(response) > 1:
                    pronoun="s are"
                response_message += f"{question_number} {room_questions_list[question_number-1]} := {len(response)} image{pronoun} selected\n"
                continue
            response_message += f"{question_number} {room_questions_list[question_number-1]} := {response}\n"
            
    bot.send_message(chat_id, response_message)

   