
import imp
import re
import telebot
import Globals
import Display
import Button
from telebot import types
import Database
import API
import os
from PIL import Image
from io import BytesIO
import Keyboard_button
import Helper

import asyncio





bot = telebot.TeleBot(API.API_KEY)



def ask_room_questions(chat_id, question_number):
    # Define your questions here
    questions = [

       "Type of the room?",
        "Price of the hotel room",
        "Picture of the room",
        "Number of available rooms"

        # Add more questions as needed
    ]

    # if question_number == 3:
    #     Globals.user[chat_id]['button_semaphore'] = "photo"
    if question_number < 3:
        Globals.user[chat_id]['button_semaphore'] = "text"

    

    if 'add room' in  Globals.user[chat_id]['manage']['account_sign_in']:

        
        
        if question_number <= len(questions):
            
            #bot.send_message(chat_id, questions[question_number - 1])
            Globals.user[chat_id]['manage']['account_sign_in']['add room']['current_question'] = question_number

            multi_image = True
            try:
                multi_image  =  Globals.user[chat_id]['manage']['account_sign_in']['image album id holder']
            except:
                multi_image

            print("i am here0")
            ## hold the message ID for number of room if it needed to be deleted in case of multiple Image insertion
            previous = " "
            if question_number in Globals.user[chat_id]['manage']['account_sign_in']['add room']:#len( Globals.user[chat_id]['manage']['account_sign_in']['add room'].keys()) == 5:
                if question_number == 3 and len(Globals.user[chat_id]['manage']['account_sign_in']['add room'][question_number]) > 0:
                    previous ="\n previous data: " +  str(len(Globals.user[chat_id]['manage']['account_sign_in']['add room'][question_number])) + " images were selected"
                elif question_number != 3:
                    previous ="\n previous data: " +  str(Globals.user[chat_id]['manage']['account_sign_in']['add room'][question_number])
            
            print(question_number,multi_image)
            if question_number != 4:
                bot.send_message(chat_id, questions[question_number - 1] + str(previous))
                if  question_number == 3:
                    Globals.user[chat_id]['manage']['account_sign_in']['image album id holder'] = True
                    Globals.user[chat_id]['button_semaphore'] = "photo"

                    try:
                        if Globals.user[chat_id]['manage']['account_sign_in']['add room'][3] != []:
                            return
                            
                    except:
                        None
                       
                    Globals.user[chat_id]['manage']['account_sign_in']['add room'][3] = []

                    

                    # if len(Globals.user[chat_id]['manage']['account_sign_in']['add room'][3]):
                    #     file_id =  Globals.user[chat_id]['manage']['account_sign_in']['add room'][3][1].file_id
                    #     file_info = bot.get_file(file_id)
        
                    #     # Download the photo using the file_path
                    #     file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'

                    #     bot.send_photo(chat_id, photo=Helper.show_image(file_url),caption="")
                        
                
                #when the question reach to 4 create an empty array
                # if question_number == 2:
                    
                      

                
            elif question_number == 4 and multi_image:
                print("i am here2")
                # try:
                    
                #     print("count")
                #     bot.delete_message(chat_id,Globals.user[chat_id]['manage']['account_sign_in']['add room']['image album id holder'])
                    
                # except:
                #     print("error message due to deletion of image album id holder ")
                # print(len(Globals.user[chat_id]['manage']['account_sign_in']['add room'][3]))
                bot.send_message(chat_id, questions[question_number - 1] + str(previous))
                
                if 'image album id holder' in Globals.user[chat_id]['manage']['account_sign_in']:
                    Globals.user[chat_id]['manage']['account_sign_in']['image album id holder'] = False
                # except:
                #     None
                
                
                Globals.user[chat_id]['button_semaphore'] = "text"
           
            # try:
            #     print(Globals.user[chat_id]['manage']['account_sign_in']['add room']['image album id holder'])
            #     bot.edit_message_reply_markup(chat_id,questions[question_number - 1] + str(previous),Globals.user[chat_id]['manage']['account_sign_in']['add room']['image album id holder'],reply_markup=Button.show_buttons(["🔙Back", "Leave"],"Sign out"))
            

            # except:
            #     print()
        
        
        else:
            try:
                del Globals.user[chat_id]['manage']['account_sign_in']['image album id holder']
                del Globals.user[chat_id]['manage']['account_sign_in']['image editor']
            except:
                None
            Helper.remove(chat_id,'Leave','🔙Back')
            


            Display.display_responses(chat_id)
            Button.buttons(chat_id)
            # if Globals.user[chat_id]['manage']['account_sign_in']['add room'][4].isdigit():
            
                

    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        
            
        if question_number <= len(questions):
            
            #bot.send_message(chat_id, questions[question_number - 1])
            Globals.user[chat_id]['manage']['account_sign_in']['edit room']['current_question'] = question_number

            #menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            if question_number == 1:
                Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])
               

                common_text ="✏️✏️✏️✏️✏️✏️✏️✏️\n "
                Helper.markup(chat_id,common_text+"please enter the room type you want to edit ",common_text+"እባክዎን ማረም የሚፈልጉትን የክፍል አይነት ያስገቡ። ", common_text+"please enter the room type you want to edit ",Button.show_buttons(["Leave","Sign out"]))

                
                Helper.remove(chat_id,'🔙Back','➡️ Skip')

            else:
                multi_image = True
                try:
                        multi_image  =  Globals.user[chat_id]['manage']['account_sign_in']['image album id holder']
                except:
                        multi_image


                text_message = " pervious room data: " if Globals.user[chat_id]['language'] == 'english' else ( "የተሳሳተ የክፍል ውሂብ;" if Globals.user[chat_id]['language'] == 'amharic' else "pervious room data: " )
                if question_number < 3:
                    # print(question_number)
                    
                    message_text =  str(questions[question_number - 1]) + "?\n\n "+ str(text_message) + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][question_number])
                    # if question_number == 2:
                    #     print(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][question_number])    
                    #     Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3] = []
                       
                    # menu_markup.row(Button.leave_button)
                    bot.send_message(chat_id, message_text, reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave"))

                    
                    

                elif question_number == 4 and  multi_image:
                    print("okay")
                    message_text =  str(questions[question_number - 1]) + "?\n\n "+ str(text_message) + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][question_number])
                    # menu_markup.row(Button.leave_button)
                    messageID_holder = bot.send_message(chat_id, message_text, reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave"))
                    
                    if 'image album id holder' in Globals.user[chat_id]['manage']['account_sign_in']:
                        Globals.user[chat_id]['manage']['account_sign_in']['image album id holder'] = False
                    # except:
                    #     None
                    Globals.user[chat_id]['button_semaphore'] = "text"
                    
                    
                elif question_number == 3:
                    Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3] = []
                    Globals.user[chat_id]['manage']['account_sign_in']['image album id holder'] = True
                    directory_path = str(Globals.user[chat_id]['manage']['account_sign_in']['room info holder']['image']).split('.')
                    print(directory_path)
                    directory_path = directory_path[0]
                    #directory_path = 'images/'+ str(Globals.user[chat_id]['manage']['account_sign_in']['account info'][1])+"_"+str(Globals.user[chat_id]['manage']['account_sign_in']['account info'][2])+"/"+str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][0]) #str(Globals.user[chat_id]['manage']['account_sign_in']['room info holder'][question_number -1 ]).split('.')
                        #directory_path = directory[0]
               
                    print(directory_path)
                        
                    Room_caption = str(questions[question_number - 1]) + "?\n\n "
                    # Send the resized image

                    Helper.show_album(chat_id,directory_path,Room_caption," pictures found \n\n" + str(questions[question_number - 1]) + "?\n ")       
                    # files = os.listdir(directory_path)

                    # # Filter out only the image files (assuming they have .jpg extension)
                    # image_files = [file for file in files if file.lower().endswith(('.jpg', '.jpeg', '.png', '.gif'))]
                    # try:
                    #     # Create a list of InputMediaPhoto objects with captions for the images
                    #     media_group = []
                    #     for file in image_files:
                    #         with open(os.path.join(directory_path, file), 'rb') as photo:
                                
                    #             media = telebot.types.InputMediaPhoto(media=photo.read(), caption=Room_caption)
                        
                    #             media_group.append(media)
                    #     bot.send_media_group(chat_id, media_group)
                    #     if(len(image_files) > 1):
                    #         bot.send_message(chat_id,Room_caption,reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave"))    
                    # except Exception as e:
                    #     print(f"Retrieve failed: {str(e)}")
                    #     bot.send_message(chat_id, "sorry could not load room pictures "+ str(len(image_files)) +" pictures found \n\n" + str(questions[question_number - 1]) + "?\n ")
                        

        
        else:
            try:
                del Globals.user[chat_id]['manage']['account_sign_in']['image album id holder']

                del Globals.user[chat_id]['manage']['account_sign_in']['image editor']
            except:
                None
            
            Helper.remove(chat_id,'🔙Back','➡️ Skip','Leave')
            # bot.send_message(chat_id, "Thank you for completing the questionnaire!")
            
            print(Globals.user[chat_id]['manage']['account_sign_in']['edit room'])
            Display.display_edited_room(chat_id)
            Button.buttons(chat_id)




def ask_question(chat_id, question_number,skip_button=False):
    # Define your questions here
    questions = []
    
    if Globals.user[chat_id]['language'] == "english":

        questions = [

        "What is the name of the hotel?",
        "which city the hotel location?",
        "GPS location",
        "user name",
        "password",
        "your phone number",
        "email address",
        "Hotel or Motel image",
        "Hotel located around"

        # Add more questions as needed
        ]
    elif Globals.user[chat_id]['language'] == "amharic":

        questions = [

        "የሆቴሉ ስም ማን ነው?",
        "ሆቴሉ የትኛው ከተማ ነው?",
        "የጂፒኤስ መገኛ",
        "የተጠቃሚ ስም",
        "የይለፍ ቃል",
        "ስልክ ቁጥርህ"
        "የ ኢሜል አድራሻ",
        "የሆቴል ወይም የሞቴል ምስል",
        "ሆቴል በአካባቢው ይገኛል"

        # Add more questions as needed
        ]
    
    elif Globals.user[chat_id]['language'] == "affan oromo":

        questions = [

        "What is the name of the hotel?",
        "which city the hotel location?",
        "GPS location",
        "user name",
        "password",
        "your phone number",
        "email address",
        "Hotel or Motel image",
        "Hotel located around"

        # Add more questions as needed
        ]



    if question_number <= len(questions):
        #to controll user input on the text field
        if question_number == 3:
            Globals.user[chat_id]['button_semaphore'] = "location"
        elif question_number == 8:
            Globals.user[chat_id]['button_semaphore'] = "photo"
        else:
            Globals.user[chat_id]['button_semaphore'] = "text"


        
        #if(len(Globals.user_form[chat_id]) != 0):
        if 'account_registration' in  Globals.user[chat_id]['manage']:
            Globals.user[chat_id]['manage']['account_registration']['current_question'] = question_number

            
            if skip_button:
                Globals.user[chat_id]['manage']['account_registration']["back to editing"] = skip_button
            
            menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            
            if question_number == 2:
                menu_markup = Button.city_list(chat_id)
                try:
                    if Globals.user[chat_id]['manage']['account_registration']["back to editing"]:
                        menu_markup.row("🔙Back","Leave","➡️ Skip")
                except:
                    menu_markup.row("🔙Back","Leave")
            elif question_number == 9:
                menu_markup = Button.net_point(chat_id,Globals.user[chat_id]['manage']['account_registration'][2])
                try:
                    if Globals.user[chat_id]['manage']['account_registration']["back to editing"]:
                        menu_markup.row("🔙Back","Leave","➡️ Skip")
                except:
                    menu_markup.row("🔙Back","Leave")
            else:
                
                try:
            
                    if Globals.user[chat_id]['manage']['account_registration']["back to editing"]:
                        
                        menu_markup.row("🔙Back","Leave","➡️ Skip")
                except:
                    
                    menu_markup.row("🔙Back","Leave")

            previous = " "
            if question_number in Globals.user[chat_id]['manage']['account_registration']:#len( Globals.user[chat_id]['manage']['account_sign_in']['add room'].keys()) == 5:
                previous ="\n previous data: " +  str(Globals.user[chat_id]['manage']['account_registration'][question_number])


            bot.send_message(chat_id, questions[question_number - 1] + previous, reply_markup=menu_markup)

            


        elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
            
            Globals.user[chat_id]['manage']['account_sign_in']['edit user']['current_question'] = question_number
            
            
            # display what the user register in the previous sign up
            message_text = None
            if question_number < 3:
                message_text = str( questions[question_number - 1]) + "? \n\n pevious data : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
                if question_number == 2:
                    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
                    menu_markup = Button.city_list(chat_id)
                    menu_markup.row("🔙Back","➡️ Skip")
                    menu_markup.row("Leave")
                    bot.send_message(chat_id, message_text, reply_markup=menu_markup)
                    return

                
            elif question_number == 3:
                message_text = str( questions[question_number - 1]) + "? \n\n pevious data Lat : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number]['latitude']) + " Long : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number]['latitude'])
            elif question_number > 3 and question_number <= len(questions) - 1:

                #decrypt hashed password for visibility
                if question_number == 5:
                    #unhashed_password = Helper.decrypt(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number].encode('utf-8'))
                    message_text = str( questions[question_number - 1]) + "? \n\n pevious data : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
                elif question_number == 8:
                    image_path = './' + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
            
                    try:
                        # with open(image_path, 'rb') as photo:
                        #     image = Image.open(photo)
                        #     # Resize the image to the desired dimensions
                        #     width = 300
                        #     height = 200
                        #     image.thumbnail((width, height))
                        #     # Convert the resized image to bytes
                        #     img_byte_array = BytesIO()
                        #     image.save(img_byte_array, format='JPEG')
                        #     img_byte_array = img_byte_array.getvalue()
                            message_text = str( questions[question_number - 1]) + "? \n\n pevious image of : " + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1])
                            Room_caption = str(message_text) 
                    
                            bot.send_photo(chat_id, photo=Helper.show_image(image_path),caption=Room_caption)

                    except Exception as e:
                        print(e)
                        message_text = str( questions[question_number - 1]) + "? \n\n pevious image : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
                        bot.send_message(chat_id, message_text, reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave"))

                      
                else:
                    message_text = str( questions[question_number - 1]) + "? \n\n pevious data : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
            
            elif question_number <= len(questions):
                if question_number == 9:
                    message_text = str( questions[question_number - 1]) + "? \n\n pevious data : "+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][question_number])
                    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
                    menu_markup = Button.net_point(chat_id,Globals.user[chat_id]['manage']['account_sign_in']['edit user'][2])
                    menu_markup.row("🔙Back","➡️ Skip")
                    menu_markup.row("Leave") 
                    bot.send_message(chat_id, message_text, reply_markup=menu_markup)
                    return
                
                
            #print the previous data except for the image since it has it own format
            if question_number != 8:    
                bot.send_message(chat_id, message_text, reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave"))
            
      

    else:
        if 'account_registration' in Globals.user[chat_id]['manage'] :
            
            try: del Globals.user[chat_id]['manage']['account_registration']["back to editing"]
            except: None
            Helper.remove(chat_id,'🔙Back','Leave',"➡️ Skip")
            
            Display.display_user_responses(chat_id)
            Button.buttons(chat_id)
        elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
            
            
            Helper.remove(chat_id,'🔙Back','➡️ Skip','Leave')
            Display.display_edited_user_responses(chat_id)
            Button.buttons(chat_id)



def login_question(chat_id, question_number):
    
    # Define your questions here
    questions = [

        "Username",
        "Password",
        # Add more questions as needed
    ]



    if question_number <= len(questions):
        bot.send_message(chat_id, questions[question_number - 1])
        if 'current_question' not in Globals.user[chat_id]['manage']['account_sign_in']:
            Globals.user[chat_id]['manage']['account_sign_in']['current_question'] = {}


        Globals.user[chat_id]['manage']['account_sign_in']['current_question'] = question_number

    else:
        del Globals.user[chat_id]['manage']['account_sign_in']['current_question']
        Load_user_info(chat_id)
        
        Globals.user[chat_id]['inline keyboard'] = ['Sign out']


def Load_user_info(chat_id):
    # retrive the username and password from database
    query = "SELECT Users_id,Hotel_name,City_location,User_password FROM users where Username = " + "'"+Globals.user[chat_id]['manage']['account_sign_in']['username'] +"'"

    Database.cursor.execute(query)
        # Fetch the results
    credentials = Database.cursor.fetchall()

    


        
    if(credentials):

        decrypted_password = Helper.decrypt(credentials[0][3].encode('utf-8'))
        print(decrypted_password)
        # password not the same exit
        if(decrypted_password != Globals.user[chat_id]['manage']['account_sign_in']['password']):
            Globals.user[chat_id]['manage']['account_sign_in'].clear()
            del  Globals.user[chat_id]['manage']['account_sign_in']
          
            Helper.markup(chat_id,"Incorrect credential please try again","የተሳሳተ ምስክርነት እባክዎ እንደገና ይሞክሩ","Incorrect credential please try again",Button.keboard_manage(chat_id))

            
            return

        
        Helper.markup(chat_id,"you are logged in ","ገብተሃል","you are logged in ",Button.show_buttons("Sign out"))
        
        
        
        Globals.user[chat_id]['manage']['account_sign_in']['account info'] = credentials[0]
        
        Helper.markup(chat_id,"Welcome! to room reservation","እንኳን በደህና መጡ! ወደ ክፍል ማስያዣ","Welcome! to room reservation",Button.keyboards(chat_id))
            
            

    else:
        
        Globals.user[chat_id]['manage']['account_sign_in'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']

    
        Helper.markup(chat_id,"Incorrect credential please try again","የተሳሳተ ምስክርነት እባክዎ እንደገና ይሞክሩ","Incorrect credential please try again",Button.keboard_manage(chat_id))




def price_filter(chat_id,data,message_id=None):
   
    Helper.remove_inline_button(chat_id,message_id)
    
    # min_price = None
    # max_price = None
    # sent_message = data
    # if sent_message.isdigit():
    #     min_price = '0'
    #     max_price = str(sent_message)

    # elif '-' in data:
    #     result = str.split(data, "-")
    #     min_price = result[0].lstrip()
    #     min_price = min_price.rstrip()

    #     max_price = result[1].lstrip()
    #     max_price = max_price.rstrip()
        
    # else:
   
    #     Keyboard_button.back_to_search(chat_id)
        
    #     Globals.user[chat_id]['search room']['offset'] = 0

    #     Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",None)
    #     return


   


    # if min_price.isdigit() and max_price.isdigit():
    #     print("okay")          

    # else:
       
    #     Keyboard_button.back_to_search(chat_id)
    #     print(Globals.city_name[chat_id])
    #     # Globals.search_by[chat_id] = "price"
    #     Globals.user[chat_id]['search room']['offset'] = 0

    #     Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",None)
    #     return
    min_price,max_price = Helper.price_filter(chat_id,data)
    print(min_price,max_price)
    if min_price ==  -1 or max_price == -1:
        return
    

    query = "SELECT DISTINCT users.Users_id , users.Hotel_name, users.Hotel_image, Phone_number, users.Hotel_priority, users.NEWIDS FROM users  Left JOIN Rooms ON  Rooms.Hotel_id = users.Users_id AND users.City_location = '"+str(Globals.user[chat_id]['search room']['search by']['search property']['city name'])+"' where Room_price >= "+str(min_price) +" and " + " Room_price <= " +str(max_price)+ " or "+ "Room_price <= " +str(min_price) +" and " + " Room_price >= " +str(max_price)  + " order by  users.Hotel_priority, users.NEWIDS DESC LIMIT" + str(Globals.user[chat_id]['search room']['offset']) +", 5"
    print(query)
    try:
               
        Database.cursor.execute(query)
        # Fetch the results
        rows = Database.cursor.fetchall()
        
        
        if len(rows) == 0:
      
            Helper.markup(chat_id,"no rooms are available","ክፍል የለም","no rooms are available",None)

            Keyboard_button.back_to_search(chat_id)
            
            #Globals.search_by[chat_id] = "price"
            Globals.user[chat_id]['search room']['offset'] = 0
          
            #Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",None) 
            return              

        result = None
        for row in rows:

            # with open(row[2], 'rb') as photo:
            #     image = Image.open(photo)
            #     # Resize the image to the desired dimensions
            #     width = 300
            #     height = 200
            #     image.thumbnail((width, height))

            #     # Convert the resized image to bytes
            #     img_byte_array = BytesIO()
            #     image.save(img_byte_array, format='JPEG')
            #     img_byte_array = img_byte_array.getvalue()

                Room_query = " select room_id,Room_type,Room_price from Rooms  where Hotel_id = " + str(row[0]) + " and Room_price >= "+str(min_price) +" and " + " Room_price <= " +str(max_price)+ " or "+ "Room_price <= " +str(min_price) +" and " + " Room_price >= " +str(max_price) 

                hotel_id,Hotel_name, Hotel_image,Phone_number,hotel_priority,newid = row
                room_identifier = [hotel_id,min_price,max_price]
                
                Phone_number = " 📞" + Phone_number
                Helper.return_info(chat_id,row[2],Room_query,Hotel_name,f"detail_image_ID_{'-'.join(map(str, room_identifier))}",f"detail_location_{hotel_id}",Phone_number)

                # Database.cursor.execute(Room_query)
                # # Fetch the results
                # Room_rows = Database.cursor.fetchall()

                # Room_caption = str(row[1]) + " hotel \n\n"
                # for Room_row in Room_rows:
                    
                #     Room_caption =  Room_caption + " 🏨 Room type  " +str(Room_row[1]) + " 💰  Room price   " +str(format(Room_row[2],',') + " Birr") + "\n\n"
                    
                # hotel_id,hotel_name, Hotel_image,hotel_priority,newid = row
                # room_identifier = [hotel_id,min_price,max_price]
                # #room_identifier = str(hotel_id) + '-' +str(min_price)+"-"+str(max_price)
                # callback_data = f"detail_image_ID_{'-'.join(map(str, room_identifier))}"

                # Detail = telebot.types.InlineKeyboardMarkup()
                #     # Create an inline button with text and a callback data
                # buttonImage = telebot.types.InlineKeyboardButton(text="Room Image", callback_data=callback_data)
                # buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=f"detail_location_{hotel_id}")
                #     # Add the button to the keyboard
                # Detail.add(buttonImage,buttonLocation)
                # bot.send_photo(chat_id, photo=Helper.show_image(row[2]),caption=Room_caption,reply_markup=Detail)


        
        if(len(rows) == 5):
          
            Helper.markup(chat_id,"\n See more rooms","\n ተጨማሪ ክፍሎችን ይመልከቱ","\n See more rooms",Button.load(chat_id))
     

    except Exception as e:
        print(f"Retrieve failed: {str(e)}")

        Helper.markup(chat_id,"something went wrong please search again","የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ","something went wrong please search again",None) 




def delete_room(chat_id, question_number):
    
    # Define your questions here
    questions = [

        "Room type",
        
        # Add more questions as needed
    ]



    if question_number <= len(questions):
        bot.send_message(chat_id, questions[question_number - 1])
        Globals.user[chat_id]['manage']['account_sign_in']['delete room']['current_question'] = question_number

    else:
        query = "SELECT Room_type FROM Rooms WHERE Hotel_id = (SELECT Users_id FROM users WHERE Username = '"+ Globals.user[chat_id]['manage']['account_sign_in']['username']+ "') and Room_type = '"+ Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1] + "'"
        print(query)
        Database.cursor.execute(query)
        
        rows = Database.cursor.fetchall()
        if len(rows) == 0:
           
            Helper.markup(chat_id, " This account do not have room information","ይህ መለያ ክፍል መረጃ የለውም "," This account do not have room information",None)
        else:
            
            Helper.remove(chat_id,'Leave')
            Button.confirm(chat_id)
    




def show_rooms(chat_id):

    query = "SELECT Room_type,Room_price,Number_of_rooms FROM Rooms WHERE Hotel_id = (SELECT Users_id FROM users WHERE Username = '"+ str(Globals.user[chat_id]['manage']['account_sign_in']['username'])+ "')"
    print(query)
    try:
        Database.cursor.execute(query)
        


        # Fetch the results
        rows = Database.cursor.fetchall()

            

        result = "\n"
        for row in rows:
            result = str(result) +  "🏨 room type "+ str(row[0]) + "💰 price " + str(format(row[1],",")) + " Birr number of rooms are  "+ str(row[2])+ '\n\n'
                    
        if len(rows) == 0:
        
            Helper.markup(chat_id,"👀Types of available room \n No available room","👀 የሚገኙ ክፍል ዓይነቶች \n ምንም ክፍል የለም።","👀Types of available room \n No available room",Button.keyboards(chat_id))
        else:
            bot.send_message(chat_id, result, reply_markup=Button.keyboards(chat_id))   
                   
    except Exception as e:
        
        print("Error executing the query:", str(e))
       
        Helper.markup(chat_id,"something went wrong can't show rooms please search again","የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ","something went wrong can't show rooms please search again",None)
    


        