#from sys import exception

import telebot
import pypyodbc as odbc
from telebot import types

# import files
import Globals
import Button
import Database
import API
from datetime import datetime



bot = telebot.TeleBot(API.API_KEY)



######## check wheather or not user start the program by using the start button##########
def check_program(chat_id):
    if chat_id in Globals.user:
        
        return False
    else:
        bot.send_message(chat_id,"please use the menu")
        return True
    
# initialize the variables for the specific user
def user_id_initialize(chat_id):
    
    if chat_id not in Globals.user:    
        Globals.user[chat_id] = {'id':chat_id,'time':datetime.now(),'language':check_user_language(chat_id),'message_id': message_id_init(chat_id),'button_semaphore':0,'inline keyboard':[]}
        
    
        
# def intialize_search_variables(chat_id):
    # Globals.more[chat_id] = 1
    # Globals.editing[chat_id] = False
    
     

    return

def message_id_init(chat_id):
    try:
        if Globals.user[chat_id]['message_id']:
            return  Globals.user[chat_id]['message_id']
        else:
            return None
    except:
        return None
    
    
# check the users preferd language
def check_user_language(chat_id):
    
    # prepare language selection or leave it if already selected
    try:
        if  Globals.user[chat_id]['language'] in ['english','amharic','affan oromo']: 
           return Globals.user[chat_id]['language']
    except Exception as e:
        print(e)   
   
    
    lookup_query = "SELECT Languages from UserId where User_TelegramId = '" + str(chat_id)+"'"
    print(lookup_query)
    try:
        Database.cursor.execute(lookup_query)
        result = Database.cursor.fetchall()
        print(result)
        
        if len(result) == 0:
            userId_query = "Insert into UserId (User_TelegramId,Languages) values ('"+str(chat_id)+"','english')"
            Database.cursor.execute(userId_query)
            Database.conn.commit()
            return 'english'
        else:
            return result[0][0]
            
            
    except Exception as e:
        print(e)
        text_message = "Sorry!! something went wrong" if Globals.user[chat_id]['language']  == 'english' else ( "አዝናለሁ!! የሆነ ስህተት ተከስቷል" if Globals.user[chat_id]['language']  == 'amharic' else "Sorry!! something went wrong" )
        bot.send_message(chat_id,text_message)
        return



