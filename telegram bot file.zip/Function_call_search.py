#from sys import exception

import telebot

from telebot import types

from PIL import Image
from io import BytesIO


# import files
import Globals

import Helper
import Button

import Database
import Near_me
import Keyboard_button
import API
bot = telebot.TeleBot(API.API_KEY)




# search by ******
def by_city(chat_id,message_id):

    menu_markup = Button.city_list(chat_id)
    menu_markup.row(types.KeyboardButton("Back to search"))

    bot.send_message(chat_id, "please enter the name of the city:", reply_markup=menu_markup)
    
    Helper.remove_inline_button(chat_id,message_id)
    Globals.user[chat_id]['message_id'] = None
    
    

    

def by_price(chat_id,message_id):
    Keyboard_button.back_to_search(chat_id)

    if Globals.user[chat_id]['search room']['search by'] == 'near me':
        Helper.remove_inline_button(chat_id,message_id)    
        Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",None)
        return
    
    
    Globals.user[chat_id]['search room']['offset'] = 0
    Helper.markup(chat_id,"please enter the range of your price \n  in a format of minimum - maximum","እባክዎ የዋጋዎን ክልል ያስገቡ \n በትንሹ - ከፍተኛ","please enter the range of your price \n  in a format of minimum - maximum",None)

    Helper.remove_inline_button(chat_id,message_id)
    
    
     

def near_me(chat_id,message_id):
    Keyboard_button.back_to_search(chat_id)
    Globals.user[chat_id]['search room']['offset'] = 0
    Near_me.Near_me(chat_id)
    Helper.remove_inline_button(chat_id,message_id)   
    

# search all rooms in the city

def all(chat_id,message_id):
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    menu_markup.row(Button.price_filter)
    message_text = "Rooms" if Globals.user[chat_id]['language'] == 'english' else ( "መኝታ ክፍሎች" if Globals.user[chat_id]['language'] == 'amharic' else "Rooms" )
    bot.send_message(chat_id, message_text, reply_markup=menu_markup)

    print(Globals.user[chat_id]['search room']['search by']['search property']['search_based'])
    Keyboard_button.back_to_search(chat_id)
    

    Helper.remove_inline_button(chat_id,message_id)
    
 
    query = "SELECT  DISTINCT  users.Users_id, users.Hotel_name, users.Hotel_image, Phone_number, users.Hotel_priority, users.NEWIDS FROM users Inner Join Rooms on users.Users_id = Rooms.Hotel_id WHERE City_location = '"+str(Globals.user[chat_id]['search room']['search by']['search property']['city name'])+"' order by  users.Hotel_priority DESC, users.NEWIDS DESC,  users.Hotel_Name DESC  LIMIT " + str(Globals.user[chat_id]['search room']['offset']) +", 5;" #OFFSET " + str(Globals.user[chat_id]['search room']['offset']) +" ROWS FETCH NEXT 5 ROWS ONLY
    
    try:
                
        Database.cursor.execute(query)
        # Fetch the results
        rows = Database.cursor.fetchall()
        
        
        if len(rows) == 0:
            Helper.markup(chat_id,"no room are available","ምንም የመኝታ ክፍል የለም","no room are available",None)


        #result = None
        for row in rows:
            
            
            image_path = './' + str(row[2])
            
            try:
                
                # with open(image_path, 'rb') as photo:
                #     image = Image.open(photo)
                #     # Resize the image to the desired dimensions
                #     width = 300
                #     height = 200
                #     image.thumbnail((width, height))
                #     # Convert the resized image to bytes
                #     img_byte_array = BytesIO()
                #     image.save(img_byte_array, format='JPEG')
                #     img_byte_array = img_byte_array.getvalue()
            

                Room_query = " select room_id, Room_type,Room_price from Rooms  where Hotel_id = " + str(row[0]) 
                hotel_id, Hotel_name,Hotel_image, Phone_number,Hotel_priority,newids = row
                callback_data_pic = f"detail_image_ID_{hotel_id}"
                callback_data_loc = f"detail_location_{hotel_id}"

                Phone_number = " 📞" + Phone_number

                Helper.return_info(chat_id,image_path,Room_query,Hotel_name,callback_data_pic,callback_data_loc,Phone_number)
                # Database.cursor.execute(Room_query)
                # Room_rows = Database.cursor.fetchall()

                # Room_caption = str(row[1]) + "  \n\n"
                # for Room_row in Room_rows:
                    
                #     Room_caption =  Room_caption + " 🏨 Room type  " +str(Room_row[1]) + " 💰  Room price   " +str(format(Room_row[2],',') + " Birr") + "\n\n"
                   
                # Detail = telebot.types.InlineKeyboardMarkup()
                # # Create an inline button with text and a callback data

                # buttonImage = telebot.types.InlineKeyboardButton(text="Rooms", callback_data=callback_data)
                # buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=f"detail_location_{hotel_id}")
                # # Add the button to the keyboard
                # Detail.add(buttonImage,buttonLocation)
                # bot.send_photo(chat_id, photo=Helper.show_image(image_path),caption=Room_caption,reply_markup=Detail)
                   
            except Exception as e:
                #skip if file path not found
                print(e)
                continue


        if(len(rows) == 5):
           
            Helper.markup(chat_id,"\n See more rooms","\n ተጨማሪ ክፍሎችን ይመልከቱ","\n See more rooms",Button.load(chat_id))
     
    except Exception as e:
        print(f"Retrieve failed: {str(e)}")
    

        Helper.markup(chat_id,"something went wrong please search again","የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ","something went wrong please search again",None)   

    



def hotel_name(chat_id):
    
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    menu_markup.row(Button.price_filter)
    message_text = "Rooms" if Globals.user[chat_id]['language'] == 'english' else ( "መኝታ ክፍሎች" if Globals.user[chat_id]['language'] == 'amharic' else "Rooms" )
    bot.send_message(chat_id, message_text, reply_markup=menu_markup)


    Keyboard_button.back_to_search(chat_id)

    query = "SELECT    HOTEL_DATA.Users_id, HOTEL_DATA.Hotel_name, HOTEL_DATA.Hotel_image from (SELECT * FROM users WHERE City_location = '"+str(Globals.user[chat_id]['search room']['search by']['search property']['city name'])+"' AND Hotel_name Like '%"+str(Globals.user[chat_id]['search room']['search by']['search property']['hotel name']) +"%') AS HOTEL_DATA order by HOTEL_DATA.Hotel_priority DESC, HOTEL_DATA.Hotel_Name DESC   LIMIT " + str(Globals.user[chat_id]['search room']['offset']) +" ,5 ;"
 
    print(query)
    try:
                
        Database.cursor.execute(query)
        # Fetch the results
        rows = Database.cursor.fetchall()
        
        if len(rows) == 0:
            Helper.markup(chat_id,"no room are available","ምንም የመኝታ ክፍል የለም","no room are available",None)

        #result = None
        for row in rows:
            # print(row[2])
            
            # image_path = './' + str(row[2])
            # with open(image_path, 'rb') as photo:
            #     image = Image.open(photo)
            #     # Resize the image to the desired dimensions
            #     width = 300
            #     height = 200
            #     image.thumbnail((width, height))
            #     # Convert the resized image to bytes
            #     img_byte_array = BytesIO()
            #     image.save(img_byte_array, format='JPEG')
            #     img_byte_array = img_byte_array.getvalue()
            

                Room_query = " select room_id, Room_type,Room_price from Rooms  where Hotel_id = " + str(row[0]) 

                Database.cursor.execute(Room_query)
                # Fetch the results
                Room_rows = Database.cursor.fetchall()
                print(Room_rows)

                Room_caption = str(row[1]) + " hotel \n\n"
                for Room_row in Room_rows:
                    
                    Room_caption =  Room_caption + " 🏨 Room type  " +str(Room_row[1]) + " 💰  Room price   " +str(format(Room_row[2],',')) + " Birr" + "\n\n"
                # Send the resized image
                # Create an inline keyboard
                hotel_id, Hotel_name,Hotel_image = row
                Detail = telebot.types.InlineKeyboardMarkup()
                    # Create an inline button with text and a callback data
                buttonImage = telebot.types.InlineKeyboardButton(text="Rooms", callback_data=f"detail_image_ID_{hotel_id}")
                buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=f"detail_location_{hotel_id}")
                    # Add the button to the keyboard
                Detail.add(buttonImage,buttonLocation)
                bot.send_photo(chat_id, photo=Helper.show_image( './' + str(row[2])),caption=Room_caption,reply_markup=Detail)


        if(len(rows) == 5):
            Helper.markup(chat_id,"\n See more rooms","\n ተጨማሪ ክፍሎችን ይመልከቱ","\n See more rooms",Button.load())
     

    except Exception as e:
        print(f"Retrieve failed: {str(e)}")
        Helper.markup(chat_id,"something went wrong please search again","የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ","something went wrong please search again",None)    

    



def net_point(chat_id):

    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    menu_markup.row(Button.price_filter)
    message_text = "Rooms" if Globals.user[chat_id]['language'] == 'english' else ( "መኝታ ክፍሎች" if Globals.user[chat_id]['language'] == 'amharic' else "Rooms" )
    bot.send_message(chat_id, message_text, reply_markup=menu_markup)


    Keyboard_button.back_to_search(chat_id)

    query = "SELECT    HOTEL_DATA.Users_id, HOTEL_DATA.Hotel_name, HOTEL_DATA.Hotel_image from (SELECT * FROM users WHERE City_location = '"+str(Globals.user[chat_id]['search room']['search by']['search property']['city name'])+"' AND Net_point = N'"+str(Globals.user[chat_id]['search room']['search by']['search property']['net point']) +"') AS HOTEL_DATA order by HOTEL_DATA.Hotel_priority DESC, HOTEL_DATA.Hotel_Name DESC   LIMIT " + str(Globals.user[chat_id]['search room']['offset']) +",5 ;"
 
    print(query)
    try:
                
        Database.cursor.execute(query)
        # Fetch the results
        rows = Database.cursor.fetchall()
        
        if len(rows) == 0:
            Helper.markup(chat_id,"no room are available","ምንም የመኝታ ክፍል የለም","no room are available",None)

        #result = None
        for row in rows:
            # print(row[2])
            
            #image_path = './' + str(row[2])
            # with open(image_path, 'rb') as photo:
            #     image = Image.open(photo)
            #     # Resize the image to the desired dimensions
            #     width = 300
            #     height = 200
            #     image.thumbnail((width, height))
            #     # Convert the resized image to bytes
            #     img_byte_array = BytesIO()
            #     image.save(img_byte_array, format='JPEG')
            #     img_byte_array = img_byte_array.getvalue()
    

                Room_query = " select room_id, Room_type,Room_price from Rooms  where Hotel_id = " + str(row[0]) 

                Database.cursor.execute(Room_query)
                # Fetch the results
                Room_rows = Database.cursor.fetchall()
                print(Room_rows)

                Room_caption = str(row[1]) + " hotel \n\n"
                for Room_row in Room_rows:
                    
                    Room_caption =  Room_caption + " 🏨 Room type  " +str(Room_row[1]) + " 💰  Room price   " +str(format(Room_row[2],',')) + " Birr" + "\n\n"

                hotel_id, Hotel_name,Hotel_image = row
                Detail = telebot.types.InlineKeyboardMarkup()
                    # Create an inline button with text and a callback data
                buttonImage = telebot.types.InlineKeyboardButton(text="Rooms", callback_data=f"detail_image_ID_{hotel_id}")
                buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=f"detail_location_{hotel_id}")
                    # Add the button to the keyboard
                Detail.add(buttonImage,buttonLocation)
                bot.send_photo(chat_id, photo=Helper.show_image('./' + str(row[2])),caption=Room_caption,reply_markup=Detail)

     
        if(len(rows) == 5):
           
            Helper.markup(chat_id,"\n See more rooms","\n ተጨማሪ ክፍሎችን ይመልከቱ","\n See more rooms",Button.load(chat_id))
     

    except Exception as e:
        print(f"Retrieve failed: {str(e)}")
        text_message = "something went wrong please search again" if Globals.user[chat_id]['language'] == 'english' else ("የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ" if Globals.user[chat_id]['language'] == 'amharic' else "something went wrong please search again" )
        bot.send_message(chat_id,text_message)
        Helper.markup(chat_id,"something went wrong please search again","የሆነ ችግር ተፈጥሯል እባክህ እንደገና ፈልግ","something went wrong please search again",None)    

    



