#from sys import exception
import telebot
from datetime import datetime, timedelta
import API
import Globals
import Helper
bot = telebot.TeleBot(API.API_KEY)



def check_inactive_users():
    # for i in range(0,20):
    print("run checking...")

    an_active_users = []   
    try:
        for user_id,user_data in Globals.user.items():

            if datetime.now() - user_data['time'] > timedelta(minutes=1):
                an_active_users.append(user_id)
                markups = telebot.types.ReplyKeyboardRemove()
                bot.send_message(user_data['id'],"session expired \n use the menu",reply_markup=markups)

                Helper.remove_inline_button(user_id,Globals.user[user_id]['message_id'])
                

        for id in an_active_users:
            
            del Globals.user[id]
            
            
    except Exception as e:
        print(str(e)+ " \n list changed while iterated")   
    an_active_users.clear()