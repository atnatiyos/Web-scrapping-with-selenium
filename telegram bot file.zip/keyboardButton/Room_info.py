
import telebot



# import files
import Globals
import os
import Button
import requests
import Database

import API



bot = telebot.TeleBot(API.API_KEY)

def creator(chat_id,directory_name):
    counter = 1
    
    for index in range(0,len( Globals.user[chat_id]['manage']['account_sign_in']['add room'][3])):

        file_id =  Globals.user[chat_id]['manage']['account_sign_in']['add room'][3][index].file_id
        file_info = bot.get_file(file_id)
        
        # Download the photo using the file_path
        file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'
        response = requests.get(file_url)

        directory_name = 'images/'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][1] +'_'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][2]        

        # Create the directory
        if not os.path.exists(directory_name):
            # Create the directory if it doesn't exist
            os.mkdir(directory_name)
        
        if not os.path.exists(directory_name + "/" +  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]):
            # Create the directory if it doesn't exist
            os.mkdir(directory_name + "/" +  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1])
       
        
        # Save the photo to a file
        with open(directory_name +'/'+  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]+ "/"+ str(counter) + '.jpg', 'wb') as f:
            f.write(response.content)
        counter = counter + 1

def room_information(chat_id):
    


    directory_name = directory_name = 'images/'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][1] +'_'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][2]        

    # counter = 1
    
    # for index in range(0,len( Globals.user[chat_id]['manage']['account_sign_in']['add room'][3])):

    #     file_id =  Globals.user[chat_id]['manage']['account_sign_in']['add room'][3][index].file_id
    #     file_info = bot.get_file(file_id)
        
    #     # Download the photo using the file_path
    #     file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'
    #     response = requests.get(file_url)

    #     directory_name = 'images/'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][1] +'_'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][2]        

    #     # Create the directory
    #     if not os.path.exists(directory_name):
    #         # Create the directory if it doesn't exist
    #         os.mkdir(directory_name)
        
    #     if not os.path.exists(directory_name + "/" +  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]):
    #         # Create the directory if it doesn't exist
    #         os.mkdir(directory_name + "/" +  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1])
       
        
    #     # Save the photo to a file
    #     with open(directory_name +'/'+  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]+ "/"+ str(counter) + '.jpg', 'wb') as f:
    #         f.write(response.content)
    #     counter = counter + 1



 

    
    image_path = directory_name +'/'+  Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]+'.jpg'

    priority_query = 'select Hotel_priority from users where Users_id = '  + str( Globals.user[chat_id]['manage']['account_sign_in']['account info'][0])   #str( Globals.user[chat_id]['manage']['account_sign_in']['username'])
    
    priority_row = None
    try:
        Database.cursor.execute(priority_query)
        priority_row = Database.cursor.fetchall()
        print(priority_row)
    except:
        bot.send_message(chat_id,"something went wrong",reply_markup=Button.keyboards(chat_id))
        return

    insert_command = "INSERT INTO Rooms(Room_type, Room_price, Room_picture, Number_of_rooms, Hotel_id,Hotel_priority) VALUES ("

    query = insert_command + "'" + str( Globals.user[chat_id]['manage']['account_sign_in']['add room'][1]) + "','" + str( Globals.user[chat_id]['manage']['account_sign_in']['add room'][2]) + "','"+ image_path +"'," + str( Globals.user[chat_id]['manage']['account_sign_in']['add room'][4]) + "," + str(  Globals.user[chat_id]['manage']['account_sign_in']['account info'][0]) +","+ str(priority_row[0][0]) + ")"
    print(query)

    try:
        
        Database.cursor.execute(query)
        Database.conn.commit()

        #### create the folder and write the image only after change in the database
        creator(chat_id,directory_name)
            

    except Exception as e:
        print(f"Insert failed: {str(e)}")
        bot.send_message(chat_id,"something went wrong",reply_markup=Button.keyboards(chat_id))
        return
        
    
    Globals.user[chat_id]['button_semaphore'] = 0
        
    markups = telebot.types.ReplyKeyboardRemove()
    bot.send_message(chat_id, " \t \t Room adding is done \n\n", reply_markup=markups)
    bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))
    del  Globals.user[chat_id]['manage']['account_sign_in']['add room']
  

