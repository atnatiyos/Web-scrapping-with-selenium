from unittest import result
import telebot

from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO

import sys

# import files
import Globals
import Display
import Helper
import Button
import Function_call

import Location_handler
import Photo_handler
import Text_handler
import Database
import Near_me
import API

import Helper

bot = telebot.TeleBot(API.API_KEY)


def user_registration_form(chat_id):
    # bot.send_message(chat_id, "Your user registration is done now you can sign in")
    
    

    Globals.user[chat_id]['button_semaphore'] = 0


    file_id = Globals.user[chat_id]['manage']['account_registration'][8].file_id
    file_info = bot.get_file(file_id)
        
    # Download the photo using the file_path
    file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'
    response = requests.get(file_url)

    directory_name = 'images/'+Globals.user[chat_id]['manage']['account_registration'][1] +'_'+Globals.user[chat_id]['manage']['account_registration'][2]        

    
    image_path = directory_name +'/'+ Globals.user[chat_id]['manage']['account_registration'][1]+'.jpg'
    hashed_password = Helper.encrypt(Globals.user[chat_id]['manage']['account_registration'][5].encode('utf-8'))
    insert_command = "INSERT INTO users(Hotel_name, City_location, GPS_location_latitude, GPS_location_longitude, Username, User_password,Phone_number, Email,Hotel_image, Telegram_id,Hotel_priority,Net_point) VALUES ("

    query = insert_command + "'" + str(Globals.user[chat_id]['manage']['account_registration'][1]) + "','" + str(Globals.user[chat_id]['manage']['account_registration'][2]) + "'," + str(Globals.user[chat_id]['manage']['account_registration'][3].latitude) + "," + str(Globals.user[chat_id]['manage']['account_registration'][3].longitude) + ",'" + str(Globals.user[chat_id]['manage']['account_registration'][4]) + "','" + str(hashed_password) + "','" + str(Globals.user[chat_id]['manage']['account_registration'][6]) + "','" + str(Globals.user[chat_id]['manage']['account_registration'][7]) + "','"+str(image_path)+"', '"+str(chat_id)+"', 0 ,N'"+ str(Globals.user[chat_id]['manage']['account_registration'][9])+"' )"
        
    print(query)
    try:

        Database.cursor.execute(query)
        Database.conn.commit()

        updated_rows = Database.cursor.rowcount
        #Button.user[chat_id]['button_semaphore'] = 1
        if(updated_rows > 0):
            
            # Create the directory
            if not os.path.exists(directory_name):
                # Create the directory if it doesn't exist
                os.mkdir(directory_name)
       
        
                # Save the photo to a file
            with open(directory_name +'/'+ Globals.user[chat_id]['manage']['account_registration'][1]+'.jpg', 'wb') as f:
                f.write(response.content)

                
            bot.send_message(chat_id, "Your registration is done now you can sign in", reply_markup=Button.keboard_manage(chat_id))

        
           
        else:
                
                
            bot.send_message(chat_id, "Something went wrong with sign up please sign up again", reply_markup=Button.keboard_manage(chat_id))
            

    except Exception as e:
        print(f"Insert failed: {str(e)}")
        bot.send_message(chat_id,"sorry someting went wrong with the registration")
    

    # redirect it in to sign in and sign up page
    markups = telebot.types.ReplyKeyboardRemove()
    bot.send_message(chat_id, "Sign in using credentials or telegram ID ", reply_markup=markups)
    Globals.user_form.clear()
