from unittest import result
import telebot

from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO

import sys

# import files
import Globals
import Display
import Helper
import Button
import Function_call
import Location_handler
import Photo_handler
import Text_handler
import Database
import Near_me
import API

from keyboardButton import user_form
from keyboardButton import Edit_user_info
from keyboardButton import Room_info
from keyboardButton import Edit_room







bot = telebot.TeleBot(API.API_KEY)


def Done(chat_id):
   

   



    # no action if the semaphore is set to 0
    # if Button.button_stage[chat_id] != 1:
    #     bot.send_chat_id(chat_id,"please dont use this button at this stage")
    #     return


    # Globals.editing[chat_id] = False
    if 'account_registration' in Globals.user[chat_id]['manage']:
        user_form.user_registration_form(chat_id)
        Globals.user[chat_id]['inline keyboard'].clear()
       
    elif 'edit user' in  Globals.user[chat_id]['manage']['account_sign_in']:
        print("done")
        Edit_user_info.edit_user_information(chat_id)
        Globals.user[chat_id]['inline keyboard'].clear()
        
    


    # save new room information 
    elif 'add room' in  Globals.user[chat_id]['manage']['account_sign_in']:
        Room_info.room_information(chat_id)
        


    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Edit_room.edit_room_information(chat_id)
        
    Globals.user[chat_id]['button_semaphore'] = 0