from unittest import result
import telebot

from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO

import sys

# import files
import Globals
import Display
import Helper
import Button
import Function_call

import Location_handler
import Photo_handler
import Text_handler
import Database
import Near_me
import API




bot = telebot.TeleBot(API.API_KEY)

def edit_room_information(chat_id):
    

        #query = "UPDATE Rooms SET Room_type = '" + str(Globals.edited_room[chat_id][1]) + "', Room_price = "+ str(Globals.edited_room[chat_id][2]) + ", Room_picture = '"+ str(Globals.edited_room[chat_id][3]) + "', Number_of_rooms = " + str(Globals.edited_room[chat_id][4]) + " WHERE Room_type = '" + str(Globals.edited_room[chat_id][1]) + "' AND Hotel_id = (SELECT Users_id from users where Username = '" + str(Globals.login_info[chat_id][1])+"')"
    query = None
    print(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3])

    if Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3] != Globals.user[chat_id]['manage']['account_sign_in']['room info holder']['image']:
    
        paths =  'images/'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][1] +'_'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][2] + "/" + Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]
        files = os.listdir(paths)
            # Loop through the list of files and delete each one
        for file in files:
            file_path = os.path.join(paths, file)  # Construct the full file path
            if os.path.isfile(file_path):  # Check if it's a file (not a directory)
                os.remove(file_path)  # Delete the file

        counter = 1
        for index in range(0,len(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3])):

            file_id = Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3][index].file_id
            file_info = bot.get_file(file_id)
        
            # Download the photo using the file_path
            file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'
            response = requests.get(file_url)

            directory_name = 'images/'+ str(Globals.user[chat_id]['manage']['account_sign_in']['account info'][1]) +'_'+ str(Globals.user[chat_id]['manage']['account_sign_in']['account info'][2])        
            
            new_path = directory_name + "/" + Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]+".jpg"
            old_path = str(Globals.user[chat_id]['manage']['account_sign_in']['room info holder']['image'])

            if  old_path == new_path:
                if not os.path.exists(directory_name + "/" + Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]):
                    # Create the directory if it doesn't exist
                    os.mkdir(new_path)
            else:
                os.rename(old_path,new_path)
            
        
            # Save the photo to a file
            with open(directory_name +'/'+ Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]+ "/"+ str(counter) + '.jpg', 'wb') as f:
                f.write(response.content)
            counter = counter + 1

        image_path = 'images/'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][1] +'_'+ Globals.user[chat_id]['manage']['account_sign_in']['account info'][2] +'/'+ Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]+'.jpg'

        query = "UPDATE Rooms SET Room_type = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]) + "', Room_price = "+ str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][2]) + ", Room_picture = '"+ str(image_path) + "', Number_of_rooms = " + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][4]) + " WHERE Room_type = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]) + "' AND Hotel_id = (SELECT Users_id from users where Username = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['username'])+"')"
    else:
        query = "UPDATE Rooms SET Room_type = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]) + "', Room_price = "+ str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][2]) + ", Room_picture = '"+ str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3]) + "', Number_of_rooms = " + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][4]) + " WHERE Room_type = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1]) + "' AND Hotel_id = (SELECT Users_id from users where Username = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['username'])+"')"
        
       
    try:
        print(Globals.user[chat_id]['manage']['account_sign_in']['edit room'][1])
 

        # Execute the query with the specified values
        Database.cursor.execute(query)

        # Commit the transaction if the update is successful
        Database.conn.commit()
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " \t \t Room update is done \n\n", reply_markup=markups)
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))

    except Exception as e:
        # Rollback the transaction if there's an error
        Database.conn.rollback()
        print("Error updating the database:", str(e))
        bot.send_message(chat_id, "Sorry!! Something went wrong cant update room information", reply_markup=Button.keyboards(chat_id))

    finally:
        Globals.user[chat_id]['manage']['account_sign_in']['edit room'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['edit room']
        del Globals.user[chat_id]['manage']['account_sign_in']['room info holder']