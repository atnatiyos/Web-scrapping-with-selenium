from unittest import result
import telebot

from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO

import sys

# import files
import Globals
import Display
import Helper
import Button
import Function_call

import Location_handler
import Photo_handler
import Text_handler
import Database
import Near_me
import API
import shutil




bot = telebot.TeleBot(API.API_KEY)


def edit_user_information(chat_id):
    
    markups = telebot.types.ReplyKeyboardRemove()
   
    
    

    lat = None
    lng = None
    try :
        lat = Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3]['latitude']
        lng = Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3]['longitude']
    except:
        lat = Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3]
        lng = Globals.user[chat_id]['manage']['account_sign_in']['edit user'][4]


    directory_name = 'images/' + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1]) +'_'+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][2])        

    old_folder_name = 'images/'+ str(Globals.user[chat_id]['manage']['account_sign_in']['account info holder']['hotel_name'])+"_"+str(Globals.user[chat_id]['manage']['account_sign_in']['account info holder']["city_location"])
        
    #check if there is a name change
    if directory_name == old_folder_name:
         # Create the directory
        if not os.path.exists(directory_name,):
            # Create the directory if it doesn't exist
            os.mkdir(directory_name)
    else:
        print(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8])
        if str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8]).startswith("images"):
            print(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8])
            shutil.move(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8], old_folder_name+"/"+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1]+'.jpg'))
        
        os.rename(old_folder_name,directory_name)
        
       
        

    Hotel_image = directory_name +'/'+ Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1]+'.jpg'
    try:
        
        file_id = Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8].file_id
        file_info = bot.get_file(file_id)
        

        # file_name = file_info.file_path
        # downloaded_file = bot.download_file(file_name)
        # Download the photo using the file_path
        file_url = f'https://api.telegram.org/file/bot{bot.token}/{file_info.file_path}'
        response = requests.get(file_url)

        
        # Save the photo to a file
        with open(directory_name +'/'+ Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1]+'.jpg', 'wb') as f:
            f.write(response.content)

        
        
    except:
        print("no new image is set")
        


    encrypt_paasword = Helper.encrypt(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][5].encode('utf-8'))
    print(encrypt_paasword)
    query = "UPDATE users SET Hotel_name = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1]) + "', City_location = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][2]) + "', GPS_location_latitude = " + str(lat) + ", GPS_location_longitude = " + str(lng) + ", Username = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][4]) + "', User_password = '" + str(encrypt_paasword) + "', Phone_number = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][6]) + "', Email = '" + str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][7])+"', Hotel_image = '" +str(Hotel_image) + "', Net_point = N'"+str(Globals.user[chat_id]['manage']['account_sign_in']['edit user'][9])+"' WHERE Username = '" + Globals.user[chat_id]['manage']['account_sign_in']['username'] + "'"

    print(query)

    try:

        Database.cursor.execute(query)
        Database.conn.commit()
        
        ###if change in the hotel name or in city location happen then room image path should also changes 
        if directory_name != old_folder_name:
            room_query = "SELECT room_id, Room_type from Rooms where Hotel_id = "+ str(Globals.user[chat_id]['manage']['account_sign_in']['account info holder']['hotel_id'])
            Database.cursor.execute(room_query)
            room_infos = Database.cursor.fetchall()

            for room_info in room_infos:
            
                update_room = "UPDATE Rooms set Room_picture = '" + str(directory_name)+"/"+room_info[1]+ ".jpg' where room_id = "+ str(room_info[0])
                print(update_room)
                
                Database.cursor.execute(update_room)
                Database.conn.commit()




        bot.send_message(chat_id, " \t \t Editing user information is done now you can re-sign in \n\n", reply_markup=markups)
    except Exception as e:
        print(f"Insert failed: {str(e)}")
        bot.send_message(chat_id,"sorry something went wrong with the update")

    # redirect it in to sign in and sign up page
    Globals.user[chat_id]['button_semaphore'] = 0
    sent_message = bot.send_message(chat_id, "  Sign in with the new Information", reply_markup=Button.keboard_manage(chat_id))
    Globals.user[chat_id]['message_id'] = sent_message.message_id

    # Globals.user[chat_id]['manage']['account_sign_in']['edit user'].clear()
    # del Globals.user[chat_id]['manage']['account_sign_in']['edit user']
    # del Globals.user[chat_id]['manage']['account_sign_in']['account info holder']
    del Globals.user[chat_id]['manage']['account_sign_in']