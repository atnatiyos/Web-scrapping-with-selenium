
import telebot
import os


# import files
import Globals
import Button
import Database
import API
import shutil


bot = telebot.TeleBot(API.API_KEY)



def Yes(chat_id):

    if 'account_registration' in Globals.user[chat_id]['manage']:
        Globals.user[chat_id]['manage']['account_registration'].clear()
        del Globals.user[chat_id]['manage']['account_registration']
        
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " \t \t you canceled the registration \n\n", reply_markup=markups)
        Globals.user[chat_id]['button_semaphore'] = 0
        bot.send_message(chat_id, "sign up is cancelled \n Manage hotel rooms", reply_markup=Button.keboard_manage(chat_id))



    elif 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['edit user'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['edit user']
        del Globals.user[chat_id]['manage']['account_sign_in']['account info holder']
        
        markups = telebot.types.ReplyKeyboardRemove()
        bot.send_message(chat_id, " \t \t you canceled the edit form \n\n", reply_markup=markups)
        Globals.user[chat_id]['button_semaphore'] = 0
        bot.send_message(chat_id,"editing account information is cancelled",Button.show_buttons("Sign out"))
        bot.send_message(chat_id, "account management board", reply_markup=Button.keyboards(chat_id))

    elif 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['edit room'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['edit room']
        del Globals.user[chat_id]['manage']['account_sign_in']['room info holder']

        # markups = telebot.types.ReplyKeyboardRemove()
        # bot.send_message(chat_id, " \t \t you canceled the edit room \n\n", reply_markup=markups)
        Globals.user[chat_id]['button_semaphore'] = 0

        bot.send_message(chat_id,"editing room information is cancelled", reply_markup=Button.show_buttons("Sign out"))
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))


    elif 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        Globals.user[chat_id]['manage']['account_sign_in']['add room'].clear()
        del Globals.user[chat_id]['manage']['account_sign_in']['add room']

        # markups = telebot.types.ReplyKeyboardRemove()
        # bot.send_message(chat_id, " \t \t you canceled adding new room \n\n", reply_markup=markups)

        Globals.user[chat_id]['button_semaphore'] = 0
        bot.send_message(chat_id,"adding mew room information is cancelled",reply_markup=Button.show_buttons("Sign out"))
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))


    elif 'delete room' in Globals.user[chat_id]['manage']['account_sign_in']:
        print("okay")
        try:
            query = "DELETE FROM Rooms WHERE Hotel_id = (SELECT Users_id FROM users WHERE Username = '"+Globals.user[chat_id]['manage']['account_sign_in']['username']+ "') AND Room_type = '"+ Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1]+"'"
            Database.cursor.execute(query)
            print(query)
            Database.conn.commit()  # Commit the changes to the database
            
            deleted_rows = Database.cursor.rowcount  # Get the number of deleted rows
            print(deleted_rows)

            if deleted_rows > 0:
                try:
                    query = "SELECT Hotel_name, City_location FROM users WHERE Username = '"+ Globals.user[chat_id]['manage']['account_sign_in']['username']+ "'"
                    Database.cursor.execute(query)

                    row = Database.cursor.fetchall()

                    file_path = 'Images/' +row[0][0]+"_" + row[0][1]+"/" + Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1]

                    print(file_path)
                    try: 
                       shutil.rmtree(file_path)
                    except OSError as e:
                        print(f"Error: {file_path} : {e.strerror}")

                except Exception as e:
                    Database.conn.rollback()  # Rollback changes in case of an error
                    print("Error executing the query:", str(e))
                    bot.send_message(chat_id,"sorry something went wrong")
  
                markups = telebot.types.ReplyKeyboardRemove()
                bot.send_message(chat_id, "Room type:- " + Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1]+" deleted", reply_markup=markups)
               
            else:
                markups = telebot.types.ReplyKeyboardRemove()
                bot.send_message(chat_id, "Room type:- "+Globals.user[chat_id]['manage']['account_sign_in']['delete room'][1] + " not found", reply_markup=markups)

        except Exception as e:
            Database.conn.rollback()  # Rollback changes in case of an error
            print("Error executing the query:", str(e))
            bot.send_message(chat_id,"sorry something went wrong")


        del Globals.user[chat_id]['manage']['account_sign_in']['delete room']
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))

    elif 'delete account' in Globals.user[chat_id]['manage']['account_sign_in']:
        query = "DELETE users where Username = '" +str(Globals.user[chat_id]['manage']['account_sign_in']['username'])+ "'"

        try:
            Database.cursor.execute(query)
            Database.conn.commit()
            deleted_rows = Database.cursor.rowcount

            if deleted_rows > 0:
                try:
                    query = "SELECT Hotel_name, City_location, Users_id FROM users WHERE Username = '"+ Globals.user[chat_id]['manage']['account_sign_in']['username']+ "'"
                    Database.cursor.execute(query)

                    row = Database.cursor.fetchall()
                    directory_path = 'images/' +row[0][0]+"_" + row[0][1]
                    if os.path.exists(directory_path):
                        # Remove the directory
                        os.rmdir(directory_path)  # This removes an empty directory
                        # If the directory is not empty, use os.removedirs(directory_path) to remove it and its parent directories if they are empty
                        print(f"{directory_path} has been removed.")
                    else:
                        print(f"{directory_path} does not exist.")
                except Exception as e:
                    Database.conn.rollback()  # Rollback changes in case of an error
                    print("Error executing the query:", str(e))
                    bot.send_message(chat_id,"sorry something went wrong")

                query2 = "DELETE Rooms WHERE Hotel_id = " +str( row[0][2])
                Database.cursor.execute(query)
                Database.conn.commit()

                Globals.user[chat_id]['manage']['account_sign_in']['account info'].clear()
                Globals.user[chat_id]['manage']['account_sign_in'].clear()
                del  Globals.user[chat_id]['manage']['account_sign_in']['account info']
                del Globals.user[chat_id]['manage']['account_sign_in']

                markups = telebot.types.ReplyKeyboardRemove()
                bot.send_message(chat_id, "Account successfuly deleted", reply_markup=markups)
                bot.send_message(chat_id, "Manage account", reply_markup=Button.keboard_manage(chat_id))
            else:
                markups = telebot.types.ReplyKeyboardRemove()
                bot.send_message(chat_id, "Unable to delete the account", reply_markup=markups)
                bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))
        except:
            markups = telebot.types.ReplyKeyboardRemove()
            bot.send_message(chat_id, "Unable to delete the account", reply_markup=markups)
            bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))

        del Globals.user[chat_id]['manage']['account_sign_in']['delete account']
        bot.send_message(chat_id, "Menus", reply_markup=Button.keyboards(chat_id))

    Globals.user[chat_id]['button_semaphore'] = 0
    


