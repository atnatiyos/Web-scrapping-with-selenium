import re
import hashlib
from cryptography.fernet import Fernet
import Globals
import Keyboard_button
import Database

import telebot
import API
bot = telebot.TeleBot(API.API_KEY)

# Email validation
def is_valid_email(email):
    # Regular expression pattern for a basic email format
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'

    # Use the re.match function to check if the email matches the pattern
    if re.match(pattern, email):
        return True
    else:
        return False

# phone number validation
def is_valid_phone_number(phone_number):
    # Regular expression pattern for a basic phone number format
    pattern = r'^\+?[0-9\s-]+$'

    # Use the re.match function to check if the phone number matches the pattern
    if re.match(pattern, phone_number) and len(phone_number) >= 10:
        return True
    else:
        return False
    

key = b'xMs-tIRScj1hdjbYMhThMR8YlJneFvSfa6IjiLyywLg='

def encrypt(data_to_encrypt):
    
    cipher_suite = Fernet(key)
    # Encrypt data
    encrypted_data = cipher_suite.encrypt(data_to_encrypt)
    encrypted_password = encrypted_data.decode('utf-8')
    return encrypted_password

def decrypt(encrypted_data):
    cipher_suite = Fernet(key)
    # Decrypt data
    decrypted_data = cipher_suite.decrypt(encrypted_data)
    decrypted_password = decrypted_data.decode('utf-8')
    return decrypted_password


def hash_password(password):
    # Convert the password to bytes (UTF-8 encoding)
    password_bytes = password.encode('utf-8')

    # Create a new SHA-256 hash object
    sha256 = hashlib.sha256()

    # Update the hash object with the password bytes
    sha256.update(password_bytes)

    # Get the hexadecimal representation of the hashed password
    hashed_password = sha256.hexdigest()

    return hashed_password



def remove(chat_id,*args):
    
    for arg in args:
        if arg in Globals.user[chat_id]['inline keyboard']:
            Globals.user[chat_id]['inline keyboard'].remove(arg)

def append(chat_id,*args):
    
    for arg in args:
        if arg not in Globals.user[chat_id]['inline keyboard']:
            Globals.user[chat_id]['inline keyboard'].append(arg)


def remove_inline_button(chat_id,message_id=None):
    
    try:
        if message_id:
            bot.edit_message_reply_markup(chat_id,message_id=message_id,reply_markup=None)       
        if Globals.user[chat_id]['message_id'] != None:
            bot.edit_message_reply_markup(chat_id,message_id=Globals.user[chat_id]['message_id'],reply_markup=None)
            Globals.user[chat_id]['message_id'] = None
        

    except Exception as e:
        print(e)


def markup(chat_id,english,amharic,oromifa,menu_markup=None):
    text_message = english if Globals.user[chat_id]['language'] == 'english' else ( amharic if Globals.user[chat_id]['language'] == 'amharic' else oromifa )
    Globals.user[chat_id]['message_id'] =  bot.send_message(chat_id,text_message,reply_markup=menu_markup).message_id
    # if menu_markup == None:
    #     bot.send_message(chat_id,text_message,reply_markup=menu_markup)
    #     # bot.delete_message(chat_id,delete_message.message_id)
    # else:
    #     Globals.user[chat_id]['message_id'] =  bot.send_message(chat_id,text_message,reply_markup=menu_markup).message_id
    #     print(menu_markup)


def show_image(path):
    from PIL import Image
    from io import BytesIO

    with open(path, 'rb') as photo:
        image = Image.open(photo)
        # Resize the image to the desired dimensions
        width = 300
        height = 200
        image.thumbnail((width, height))

        # Convert the resized image to bytes
        img_byte_array = BytesIO()
        image.save(img_byte_array, format='JPEG')
        img_byte_array = img_byte_array.getvalue()
        return img_byte_array


def show_album(chat_id,directory_path,Room_caption,message=""):
    import os
    import Button
    files = os.listdir(directory_path)
    # Filter out only the image files (assuming they have .jpg extension)
    image_files = [file for file in files if file.lower().endswith(('.jpg', '.jpeg', '.png', '.gif'))]
    try:
        # Create a list of InputMediaPhoto objects with captions for the images
        media_group = []
        for file in image_files:
            with open(os.path.join(directory_path, file), 'rb') as photo:
                #caption = f"{Room_caption}"  # Replace with your desired caption
                media = telebot.types.InputMediaPhoto(media=photo.read(), caption=Room_caption)
                        
                media_group.append(media)
        bot.send_media_group(chat_id, media_group)
        if(len(image_files) > 1):
            bot.send_message(chat_id,Room_caption)#,reply_markup=Button.show_buttons(["🔙Back","➡️ Skip"],"Leave")
    except Exception as e:
        print(f"Retrieve failed: {str(e)}")
        bot.send_message(chat_id, "sorry could not load room pictures "+ str(len(image_files)) + str(message))
        return



def price_filter(chat_id, data):
    print(data)

    min_price = -1
    max_price = -1

    if data.isdigit():
        min_price = 0
        max_price = data
        return min_price, max_price

    elif "-" in data:
        result = data.split("-")
        print(result)
        try:
            min_price = int(result[0].strip())
            max_price = int(result[1].strip())

            return min_price, max_price
        except ValueError:  # Handle invalid numeric conversion
            text = "Invalid price format. Please enter numbers only."
            markup(chat_id,text,text,text, None)
            #Keyboard_button.back_to_search(chat_id)
            return min_price, max_price
    else:
        text = "Please enter the range of your price in a format of minimum - maximum."
        markup(chat_id,text,text,text, None)
        return min_price, max_price




def return_info(chat_id,image_path,Room_query,hotel_name,callback_data_pic,callback_data_loc,phone_number = None,message=None):
    Database.cursor.execute(Room_query)
    Room_rows = Database.cursor.fetchall()
    
    # if(len(Room_rows) == 0):
    #     return

    if message == None:
        Room_caption = str(hotel_name) + " " +phone_number+ "  \n\n"
    else:
        Room_caption = str(message) + " " + phone_number + " \n\n"

  

    room_ids = []   
    for Room_row in Room_rows:
        room_ids.append(Room_row[0])       
        Room_caption =  str(Room_caption) + " 🏨 Room type  " +str(Room_row[1]) + " 💰  Room price   " +str(Room_row[2]) + " Birr" + "\n\n"
    print(phone_number)
    concatenated_string= "" #str(", ".join(room_ids))
    for element in room_ids:
        concatenated_string += str(element) + ","
        # Remove the trailing comma
    del room_ids
    
    Detail = telebot.types.InlineKeyboardMarkup()
    # Create an inline button with text and a callback data

    buttonImage = telebot.types.InlineKeyboardButton(text="Rooms", callback_data=f"detail_image_ID_{concatenated_string}")
    buttonLocation = telebot.types.InlineKeyboardButton(text="locate hotel", callback_data=callback_data_loc)
    # Add the button to the keyboard
    Detail.add(buttonImage,buttonLocation)
    bot.send_photo(chat_id, photo=show_image(image_path),caption=Room_caption,reply_markup=Detail)
    