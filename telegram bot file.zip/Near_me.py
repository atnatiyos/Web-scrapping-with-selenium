import re
import telebot
import Globals
import Display
import Button
from telebot import types
import Database
import math
import API





bot = telebot.TeleBot(API.API_KEY)

def Near_me(chat_id):
    # Globals.near_me[chat_id] = True
    bot.send_message(chat_id,"Please send your location")


def haversine_distance(lat1, lon1, lat2, lon2):
    # Radius of the Earth in kilometers
    R = 6371.0
    
    # Convert latitude and longitude from degrees to radians
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)
    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)
    
    # Differences in coordinates
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    
    # Haversine formula
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    # Calculate the distance
    distance = R * c
    
    print(f"Distance: {distance:.2f} km")
    return f"Distance: {distance:.2f} km"

# Example coordinates (latitude and longitude) for two points




