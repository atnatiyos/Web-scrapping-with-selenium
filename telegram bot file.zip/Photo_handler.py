import re
import telebot
import Globals
import Display
import Button
from telebot import types
import Function_call
import API
import time
import random





bot = telebot.TeleBot(API.API_KEY)



def handle_images(message):
    
    
    # if Button.button_semaphore[message.chat.id] == 1:

    #     Button_enforcer.use_only_button(message)
        
    #     return

    chat_id = message.chat.id
    if 'account_registration' in Globals.user[chat_id]['manage']:
        current_question = Globals.user[chat_id]['manage']['account_registration'].get('current_question', None)
        if current_question == 8:
            Globals.user[chat_id]['manage']['account_registration'][current_question] = message.photo[-1]
            Function_call.ask_question(chat_id, current_question + 1)
        else:
            text_message = "Please answer with correct answer format." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛው የመልስ ቅርጸት ይመልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
            bot.send_message(chat_id, text_message)


    elif 'account_sign_in' in Globals.user[chat_id]['manage'] and 'add room' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['add room'].get('current_question', None)
        print("from image " + str(current_question))
        if current_question is not None and current_question == 3:
            
            try:
                #instead of append clear and add when changing image
                if Globals.user[chat_id]['manage']['account_sign_in']['image editor']:
                    Globals.user[chat_id]['manage']['account_sign_in']['add room'][3] = []
                    Globals.user[chat_id]['manage']['account_sign_in']['image editor'] = False
            except:
                None
            
            Globals.user[chat_id]['manage']['account_sign_in']['add room'][3].append(message.photo[-1])
            
            
            random_number = random.randint(1, 5)
            time.sleep(random_number)
            
            Function_call.ask_room_questions(chat_id, 4)
           
           
    
        else:
            text_message = "Please reply with correct answer reply." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛ መልስ መልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
            bot.send_message(chat_id, text_message)
            Function_call.ask_room_questions(chat_id, current_question)


    elif 'account_sign_in' in Globals.user[chat_id]['manage'] and 'edit room' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question = Globals.user[chat_id]['manage']['account_sign_in']['edit room'].get('current_question', None)
        if current_question == 3:

            try:
                #instead of append clear and add when changing image
                if Globals.user[chat_id]['manage']['account_sign_in']['image editor']:
                    Globals.user[chat_id]['manage']['account_sign_in']['add room'][3] = []
                    Globals.user[chat_id]['manage']['account_sign_in']['image editor'] = False
            except:
                None
                
            Globals.user[chat_id]['manage']['account_sign_in']['edit room'][3].append(message.photo[-1])
            random_number = random.randint(1, 5)
            time.sleep(random_number)
            Function_call.ask_room_questions(chat_id, 4)
            # Globals.edited_room[chat_id][current_question] = message.photo[-1] 
            #Function_call.ask_room_questions(chat_id, current_question + 1)
        else:
            text_message = "Please answer with correct answer format." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛው የመልስ ቅርጸት ይመልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
            bot.send_message(chat_id, text_message)
            Function_call.ask_room_questions(chat_id, current_question)

    

    elif 'account_sign_in' in Globals.user[chat_id]['manage'] and 'edit user' in Globals.user[chat_id]['manage']['account_sign_in']:
        current_question =  Globals.user[chat_id]['manage']['account_sign_in']['edit user'].get('current_question', None)
        if current_question == 8:
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][current_question] = message.photo[-1]
            Function_call.ask_question(chat_id, current_question + 1)
        else:
            text_message = "Please answer with correct answer format." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛው የመልስ ቅርጸት ይመልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
            bot.send_message(chat_id, text_message)

    else:
        text_message = "Please answer with correct answer format." if Globals.user[chat_id]['language'] == 'english' else ( "እባክዎ በትክክለኛው የመልስ ቅርጸት ይመልሱ።" if Globals.user[chat_id]['language'] == 'amharic' else "Please reply with correct answer reply." )
        bot.send_message(chat_id, text_message)