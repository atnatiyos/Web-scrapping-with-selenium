import telebot
from telebot import types
import API
import pypyodbc as odbc

import Database
import Globals
import Keyboard_button
import Helper

bot = telebot.TeleBot(API.API_KEY)

button_semaphore = {}
button_stage = {}

######### Language defination for each buttons

def options():
    option = types.InlineKeyboardMarkup()
    
    search = types.InlineKeyboardButton(" search room", callback_data="search")
    manage = types.InlineKeyboardButton(" manage account", callback_data="manage")
    
    option.add(search,manage)

    return option


def keyboard(chat_id):
    keyboard = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        button_search = types.InlineKeyboardButton('🔎 search room', callback_data="search room")
        keyboard.add(button_search)
    elif Globals.user[chat_id]['language'] == 'amharic':
        button_search = types.InlineKeyboardButton('🔎 የመኝታ ክፍል\n መፈለግ', callback_data="search room")
        keyboard.add(button_search)
    elif Globals.user[chat_id]['language'] == 'affan oromo':
        button_search = types.InlineKeyboardButton('🔎 search room', callback_data="search room")
        keyboard.add(button_search)
    return keyboard

def keboard_manage(chat_id):
    
    Manage = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        button1 = types.InlineKeyboardButton("🔑 sign in", callback_data="sign in")
        button2 = types.InlineKeyboardButton("📝 sign up", callback_data="sign up")
        forget = types.InlineKeyboardButton("forget password", callback_data="forget password")
        Manage.add(button1, button2)
        Manage.add(forget)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        button1 = types.InlineKeyboardButton("🔑 መግባት", callback_data="sign in")
        button2 = types.InlineKeyboardButton("📝 መመዝገብ", callback_data="sign up")
        forget = types.InlineKeyboardButton("የይለፍ ቃል መርሳት", callback_data="forget password")
        Manage.add(button1, button2)
        Manage.add(forget)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        button1 = types.InlineKeyboardButton("🔑 sign in", callback_data="sign in")
        button2 = types.InlineKeyboardButton("📝 sign up", callback_data="sign up")
        forget = types.InlineKeyboardButton("forget password", callback_data="forget password")
        Manage.add(button1, button2)
        Manage.add(forget)


    return Manage


    

def search_room(chat_id,near_me = 0):
    search_room = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        all = types.InlineKeyboardButton(" all", callback_data="all")
        by_price = types.InlineKeyboardButton("🔍 filter price", callback_data="filter price")
        net_point = types.InlineKeyboardButton(" located around", callback_data="net point")
        specific = types.InlineKeyboardButton("Hotel name", callback_data="specific")
        search_room.add(all,by_price)
        if near_me == 0:
            search_room.add(net_point,specific)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        all = types.InlineKeyboardButton(" ሁሉም", callback_data="all")
        by_price = types.InlineKeyboardButton("🔍 በዋጋ ያጣሩ", callback_data="filter price")
        net_point = types.InlineKeyboardButton(" located around", callback_data="net point")
        specific = types.InlineKeyboardButton("Hotel name", callback_data="specific")
        search_room.add(all,by_price)    
        if near_me == 0:
            search_room.add(net_point,specific)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        all = types.InlineKeyboardButton(" all", callback_data="all")
        by_price = types.InlineKeyboardButton("🔍 filter price", callback_data="filter price")
        
        net_point = types.InlineKeyboardButton(" locate around", callback_data="net point")
        specific = types.InlineKeyboardButton("Hotel name", callback_data="specific")
        search_room.add(all,by_price)    
        if near_me == 0:
            search_room.add(net_point,specific)


    return search_room


def load(chat_id):
    load = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        more = types.InlineKeyboardButton(" more", callback_data="more")
        load.add(more)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        more = types.InlineKeyboardButton(" ተጨማሪ", callback_data="more")
        load.add(more)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        more = types.InlineKeyboardButton(" more", callback_data="more")
        load.add(more)


    return load


def login_type(chat_id):
    login_type = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        with_credential = types.InlineKeyboardButton("with credential", callback_data="credential")
        with_telegram = types.InlineKeyboardButton("with telegram", callback_data="telegram")
        login_type.add(with_credential,with_telegram)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        with_credential = types.InlineKeyboardButton("የይለፍ ቃል በመጠቀም", callback_data="credential")
        with_telegram = types.InlineKeyboardButton("በቴሌግራም መታወቂያ በመጠቀም", callback_data="telegram")
        login_type.add(with_credential,with_telegram)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        with_credential = types.InlineKeyboardButton("with credential", callback_data="credential")
        with_telegram = types.InlineKeyboardButton("with telegram", callback_data="telegram")
        login_type.add(with_credential,with_telegram)


    return login_type


def credential_login(chat_id):
    credential_login = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        with_credential = types.InlineKeyboardButton("with credential", callback_data="credential")
        credential_login.add(with_credential)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        with_credential = types.InlineKeyboardButton("የይለፍ ቃል በመጠቀም", callback_data="credential")
        credential_login.add(with_credential)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        with_credential = types.InlineKeyboardButton("with credential", callback_data="credential")
        credential_login.add(with_credential)


    return credential_login



def keyboards(chat_id):
    keyboards = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        Show_room_button = types.InlineKeyboardButton("👀 show rooms", callback_data="show rooms")
        Add_room_button = types.InlineKeyboardButton("➕ add room", callback_data="add room")
        Edit_room_button = types.InlineKeyboardButton("✏️ edit room", callback_data="edit room")
        Edit_user_button = types.InlineKeyboardButton("✏️ edit user", callback_data="edit user")
        Delete_button = types.InlineKeyboardButton("🗑️ delete room", callback_data="delete Room")
        Delete_account = types.InlineKeyboardButton("🗑️ delete account", callback_data="delete account")
        keyboards.add(Show_room_button)
        keyboards.add(Add_room_button, Edit_room_button)
        keyboards.add(Edit_user_button,Delete_button)
        keyboards.add(Delete_account)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        Show_room_button = types.InlineKeyboardButton("👀 ክፍሎችን አሳይ", callback_data="show rooms")
        Add_room_button = types.InlineKeyboardButton("➕ ክፍል ያክሉ", callback_data="add room")
        Edit_room_button = types.InlineKeyboardButton("✏️ የክፍል መረጃን ያርትዑm", callback_data="edit room")
        Edit_user_button = types.InlineKeyboardButton("✏️ የተጠቃሚ መለያ መረጃን ያርትዑ", callback_data="edit user")
        Delete_button = types.InlineKeyboardButton("🗑️ ክፍል ይሰርዙ", callback_data="delete Room")
        Delete_account = types.InlineKeyboardButton("🗑️ መለያ ይሰርዙ", callback_data="delete account")
        keyboards.add(Show_room_button)
        keyboards.add(Add_room_button, Edit_room_button)
        keyboards.add(Edit_user_button,Delete_button)
        keyboards.add(Delete_account)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        Show_room_button = types.InlineKeyboardButton("👀 show rooms", callback_data="show rooms")
        Add_room_button = types.InlineKeyboardButton("➕ add room", callback_data="add room")
        Edit_room_button = types.InlineKeyboardButton("✏️ edit room", callback_data="edit room")
        Edit_user_button = types.InlineKeyboardButton("✏️ edit user", callback_data="edit user")
        Delete_button = types.InlineKeyboardButton("🗑️ delete room", callback_data="delete Room")
        Delete_account = types.InlineKeyboardButton("🗑️ delete account", callback_data="delete account")
        keyboards.add(Show_room_button)
        keyboards.add(Add_room_button, Edit_room_button)
        keyboards.add(Edit_user_button,Delete_button)
        keyboards.add(Delete_account)


    return keyboards



def keyboard_filter(chat_id):
    
    keyboard_filter = types.InlineKeyboardMarkup()
    if Globals.user[chat_id]['language'] == 'english':
        
        by_name = types.InlineKeyboardButton("🔎 search by city", callback_data="search by city")
        near_me = types.InlineKeyboardButton("🌍 near me", callback_data="near me", request_location=True)
        keyboard_filter.add(by_name,near_me)
       
        
    elif Globals.user[chat_id]['language'] == 'amharic':
        by_name = types.InlineKeyboardButton("🔎 በከተማ መፈለግ", callback_data="search by city")
        near_me = types.InlineKeyboardButton("🌍 አጠገቤ", callback_data="near me", request_location=True)
        keyboard_filter.add(by_name,near_me)


    elif Globals.user[chat_id]['language'] == 'affan oromo':
        by_name = types.InlineKeyboardButton("🔎 search by city", callback_data="search by city")
        near_me = types.InlineKeyboardButton("🌍 near me", callback_data="near me", request_location=True)
        keyboard_filter.add(by_name,near_me)


    return keyboard_filter

language = types.InlineKeyboardMarkup()
Engish = types.InlineKeyboardButton("English", callback_data="english")
Amharic = types.InlineKeyboardButton("አማርኛ", callback_data="amharic")
Oromifa = types.InlineKeyboardButton("Affan oromo", callback_data="affan oromo")
language.add(Engish,Amharic,Oromifa)


#now you logged in list the menu


back_button = types.KeyboardButton("🔙Back")
skip_button = types.KeyboardButton("➡️ Skip")
signout_button = types.KeyboardButton("Sign out")
leave_button = types.KeyboardButton("Leave")

all = types.KeyboardButton("all") 
price_filter = types.KeyboardButton("filter price")
Back_to_search = types.KeyboardButton("Back to search")
filter_by = types.KeyboardButton("filter by")
#list_of_cities = types.KeyboardButton("List of cities")

def city_list(chat_id):
    
    query = "select Distinct City_location from users"
    Database.cursor.execute(query)
    # Fetch the results
    rows = Database.cursor.fetchall()
    
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    # menu_markup.row(types.KeyboardButton("Back to search"))
    for row in rows:   
        menu_markup.row(types.KeyboardButton(row[0]))
        
    Globals.user[chat_id]['button_semaphore'] = 'text'   
    return menu_markup
    # bot.send_message(chat_id, "please enter the name of the city:", reply_markup=menu_markup)
    


def net_point(chat_id,city_name):
    
    
    query = "select Distinct Net_point from users where City_location = '"+str(city_name)+"'"
    Database.cursor.execute(query)
    # Fetch the results
    rows = Database.cursor.fetchall()
    
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    menu_markup.row(types.KeyboardButton("Back to search"))
    for row in rows:   
        menu_markup.row(types.KeyboardButton(row[0]))
        
        
    Globals.user[chat_id]['button_semaphore'] = 'text'
    #bot.send_message(chat_id, "net point:", reply_markup=menu_markup)
    return menu_markup
    


def buttons(chat_id):
    Helper.append(chat_id,'✅ Done','🚫 cancel','Back to editing')
    bot.send_message(chat_id, "Choose an option:", reply_markup= show_buttons(["✅ Done","🚫 cancel"],"Back to editing"))


def confirm(chat_id):

    Helper.append(chat_id,'❌ No','✔️ Yes')
    Helper.remove(chat_id,'🚫 cancel')
    bot.send_message(chat_id, "Choose an option:", reply_markup=show_buttons(["✔️ Yes","❌ No"]))


def show_buttons(*args):
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    for arg in args:
        if isinstance(arg, list):
            menu_markup.row(*arg)
        else:
            menu_markup.add(arg)
    return menu_markup




