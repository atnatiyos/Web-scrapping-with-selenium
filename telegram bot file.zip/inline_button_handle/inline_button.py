#from sys import exception
from email import message
from subprocess import call
from unittest import result
import telebot
from telebot import types
import requests
from pathlib import Path
import os
from PIL import Image
from io import BytesIO
import sys

import Globals
import Button
import API
import initialize
import Function_call
import Function_call_search
import Helper
import Database


bot = telebot.TeleBot(API.API_KEY)


def room_search(chat_id):
    
    Globals.user[chat_id]['inline keyboard'].clear()
    
    Globals.user[chat_id]['button_semaphore'] = 0

    if 'search room' in Globals.user[chat_id]:
        Globals.user[chat_id]['search room'].clear()
    else:
        Globals.user[chat_id]['search room'] = {}
    Globals.user[chat_id]['search room']['offset'] = 0

    
    Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])
    markups = telebot.types.ReplyKeyboardRemove()
    delete_message = bot.send_message(chat_id,"🔎🔎🔎🔎🔎🔎🔎",reply_markup=markups)
    bot.delete_message(chat_id,delete_message.message_id,0)
    Helper.markup(chat_id,"Filter based on city name where the hotel located or look for near by available rooms ","ሆቴሉ በሚገኝበት የከተማ ስም አጣራ ወይም በሚገኙ ክፍሎች አጠገብ ይፈልጉ ","Filter based on city name where the hotel located or look for near by available rooms ",Button.keyboard_filter(chat_id))

    

def manage_account(chat_id):
    Globals.user[chat_id]['inline keyboard'].clear()
    Globals.user[chat_id]['button_semaphore'] = 0

    if 'manage' in Globals.user[chat_id]:
        Globals.user[chat_id]['manage'].clear()
    else:
        Globals.user[chat_id]['manage'] = {}

    Helper.remove_inline_button(chat_id,Globals.user[chat_id]['message_id'])
    markups = telebot.types.ReplyKeyboardRemove()
    delete_message = bot.send_message(chat_id,'Wellcome to hotel & motel room management',reply_markup=markups)
    bot.delete_message(chat_id,delete_message.message_id)

    Helper.markup(chat_id,"sign up for creating a new account or sign in if account already exist","አዲስ መለያ ለመፍጠር ይመዝገቡ ወይም መለያ ቀድሞውኑ ካለ ይግቡ","sign up for creating a new account or sign in if account already exist",Button.keboard_manage(chat_id))
    Globals.user[chat_id]['button_semaphore'] = 0



def signup(chat_id,message_id):


    if 'account_sign_in' in Globals.user[chat_id]['manage']:
        Helper.markup(chat_id,"sorry you are already logged in \n to sign up you should log out first","ይቅርታ ገብተሃል \n ለመመዝገብ መጀመሪያ ዘግተህ ውጣ","sorry you are already logged in \n to sign up you should log out first",None)
        return
    else:
        Globals.user[chat_id]['manage']['account_registration'] = {}
        Globals.user[chat_id]['button_semaphore'] = "text"
        common_text = "📝📝📝📝📝📝📝📝📝📝📝📝📝📝 \n"
        Helper.markup(chat_id,common_text+"Start user registration form",common_text+" ምዝገባ ቅጽ ይጀምሩ",common_text+"Start user registration form",None)
      
        Function_call.ask_question(chat_id, 1)
        Helper.remove_inline_button(chat_id,message_id)
      
        Globals.user[chat_id]['inline keyboard'].clear()
        Helper.append(chat_id,'Leave','🔙Back')
        



def signin(chat_id,message_id):


    Helper.remove_inline_button(chat_id,message_id)
    
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    Globals.user[chat_id]['inline keyboard'] = ['Leave']
    menu_markup.row(Button.leave_button)

    Helper.markup(chat_id,"use credential to login with username and password or use telegram to login with telegram id","use credential to login with username and password or use telegram to login with telegram id","use credential to login with username and password or use telegram to login with telegram id",menu_markup)
    Globals.user[chat_id]['manage']['account_sign_in'] = {'username':None,'password':None}
    Helper.markup(chat_id, "Login with: ", "Login with: ", "Login with: ",Button.login_type(chat_id)) 
    Globals.user[chat_id]['button_semaphore'] = 0
        




def add(chat_id,message_id): 
    bot.send_chat_action(chat_id, 'typing')

    if 'account_sign_in' in Globals.user[chat_id]['manage']:

        Globals.user[chat_id]['manage']['account_sign_in']['add room'] = {}  # Initialize responses for this user

        common_text = "➕➕➕➕➕➕➕➕➕\n "
        Helper.markup(chat_id,common_text+"now add the other type of the room ",common_text+"አሁን የክፍሉን ሌላ ዓይነት ይጨምሩ ",common_text+"now add the other type of the room ", Button.show_buttons(["🔙Back", "Leave"],"Sign out"))
        Function_call.ask_room_questions(chat_id, 1)
        Helper.remove_inline_button(chat_id,message_id)

        Globals.user[chat_id]['inline keyboard'].append('Leave')
        Globals.user[chat_id]['inline keyboard'].append('🔙Back')

    else:
        Helper.markup(chat_id,"please login first ","እባክዎ መጀመሪያ ይግቡ ","please login first ",None)


def delete_room(chat_id,message_id):
    
    
    Globals.user[chat_id]['manage']['account_sign_in']['delete room'] = {} 
    if 'delete room' in Globals.user[chat_id]['manage']['account_sign_in']:
        menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        menu_markup.row(Button.signout_button, Button.leave_button)
        
        Helper.markup(chat_id,"which room type you want to delete","የትኛውን ክፍል አይነት መሰረዝ ይፈልጋሉ","which room type you want to delete",menu_markup)
        
        Helper.remove_inline_button(chat_id,message_id)
        Globals.user[chat_id]['button_semaphore'] = "text"
        Function_call.delete_room(chat_id, 1)
        Helper.append(chat_id,'Leave')

    else:
        Helper.markup(chat_id,"please login first ","እባክዎ መጀመሪያ ይግቡ ","please login first ",None)


    



def edit_room(chat_id,message_id):
    bot.send_chat_action(chat_id, 'typing')
    
    Helper.remove_inline_button(chat_id,message_id)
    Globals.user[chat_id]['manage']['account_sign_in']['edit room'] = {}
    Helper.append(chat_id,"Leave")
    Function_call.ask_room_questions(chat_id, 1)
    
    # Button.show_buttons("Leave","Sign out")


def edit_user(chat_id,message_id):
    bot.send_chat_action(chat_id, 'typing')
    Globals.user[chat_id]['manage']['account_sign_in']['edit user'] = {}
    Globals.user[chat_id]['manage']['account_sign_in']['account info holder'] = []

    common_text = "✏️✏️✏️✏️✏️✏️✏️✏️✏️\n "
    Helper.markup(chat_id,common_text+"edit your user information",common_text+"የተጠቃሚ መረጃዎን ያርትዑ ",common_text+"edit your user information",None)
    Helper.remove_inline_button(chat_id,message_id)
    
    query = "SELECT Users_id,Hotel_name,City_Location, GPS_location_latitude,GPS_location_longitude,Username,User_password, Phone_number, Email, Hotel_image, Net_point FROM users where Username = '" +Globals.user[chat_id]['manage']['account_sign_in']['username'] +"'" #+ 'and User_password = ' + "'"+Globals.login_info[chat_id][2]+ "'"
    try:
        Database.cursor.execute(query)
        # Fetch the results
        user_data = Database.cursor.fetchall()
        
        for data in user_data:
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][1] = data[1]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][2] = data[2]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][3] = {'latitude':data[3],'longitude':data[4]}
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][4] = data[5]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][5] = Helper.decrypt(data[6].encode('utf-8'))
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][6] = data[7]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][7] = data[8]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][8] = data[9]
            Globals.user[chat_id]['manage']['account_sign_in']['edit user'][9] = data[10]
            
        Globals.user[chat_id]['manage']['account_sign_in']['account info holder'] = {'hotel_id':user_data[0][0] ,'hotel_name':user_data[0][1],'city_location':user_data[0][2]}
            # print(Globals.user[chat_id]['manage']['account_sign_in']['account info holder'])
        
        Function_call.ask_question(chat_id, 1)

        Globals.user[chat_id]['inline keyboard'].append('Leave')
        Globals.user[chat_id]['inline keyboard'].append('🔙Back')
        Globals.user[chat_id]['inline keyboard'].append('➡️ Skip')
    except Exception as e:
        print(e)
        Helper.markup(chat_id," something went wrong!!! "," የሆነ ስህተት ተከስቷል!!! "," something went wrong!!! ",Button.keboard_manage(chat_id))




def show_rooms(chat_id,message_id):
    Helper.remove_inline_button(chat_id,message_id)
    Function_call.show_rooms(chat_id)
    Globals.user[chat_id]['button_semaphore'] = 0

